package com.example.data

object Catalog {
    val categoryProfiles = mapOf(
        "Chatbots & LLMs" to Profile("#55b7ff", "web", "General-purpose assistant for chat, reasoning, writing, search, and knowledge work."),
        "Coding Agents" to Profile("#36d399", "hybrid", "Developer-focused AI agent or assistant for code generation, review, debugging, and software projects."),
        "Image & Design" to Profile("#ff8bd1", "web", "Creative AI tool for image generation, editing, design production, or visual asset workflows."),
        "Video & Audio" to Profile("#ffbf5f", "web", "AI media tool for video generation, editing, voice, music, transcription, or meeting capture."),
        "Productivity" to Profile("#b9f26d", "web", "Work assistant for documents, presentations, scheduling, notes, automation, and team operations."),
        "Research & Data" to Profile("#9fa8ff", "web", "AI research, analytics, data science, legal, finance, or knowledge discovery application."),
        "Marketing & Sales" to Profile("#f79256", "web", "Go-to-market AI for content, SEO, support, sales operations, customer success, and growth workflows.")
    )

    data class Profile(val accent: String, val runtime: String, val summary: String)

    val cliCommands = mapOf(
        "Claude Code" to CliCommand("npm install -g @anthropic-ai/claude-code", "claude", "Requires Node.js 18+ and a Claude.ai or Anthropic Console account."),
        "OpenAI Codex" to CliCommand("npm install -g @openai/codex", "codex", "Use the official OpenAI Codex docs for your account and platform before running a global install."),
        "Gemini Code Assist" to CliCommand("Install from the official Gemini Code Assist page or IDE extension marketplace.", "Open your IDE and start Gemini Code Assist from the extension panel.", "Best launched inside VS Code, JetBrains IDEs, or supported Google Cloud developer surfaces."),
        "Aider" to CliCommand("python -m pip install aider-install", "aider", "Runs locally in a terminal and connects to your chosen model provider."),
        "Cline" to CliCommand("Install the Cline extension from the VS Code Marketplace.", "Open VS Code, then open the Cline sidebar.", "Runs as an IDE extension rather than a standalone website."),
        "Roo Code" to CliCommand("Install Roo Code from the VS Code Marketplace.", "Open VS Code, then open Roo Code.", "Agentic coding extension for local projects."),
        "Continue" to CliCommand("Install Continue from the VS Code or JetBrains Marketplace.", "Open your IDE, then start Continue from its panel.", "Open-source assistant that can connect to local or hosted models."),
        "Amazon Q Developer" to CliCommand("Install Amazon Q Developer from AWS or your IDE extension marketplace.", "Open the Amazon Q panel in your IDE or AWS console.", "Requires an AWS Builder ID or AWS account depending on usage."),
        "GitHub Copilot" to CliCommand("Install GitHub Copilot from your IDE extension marketplace.", "Open your IDE and sign in with GitHub.", "Also available in GitHub.com surfaces for supported plans."),
        "Google Antigravity" to CliCommand("Download Google Antigravity from antigravity.google.", "Open the Antigravity desktop app after installation.", "Desktop IDE-style runtime; this launcher opens its official download page."),
        "Gemini CLI" to CliCommand("npm install -g @google/gemini-cli", "gemini-cli", "Requires Node.js 18+ and a Gemini API key setup in your CLI prompt."),
        "VS Code" to CliCommand("Download VS Code from code.visualstudio.com/Download", "code .", "Install VS Code with Copilot or Cline extension for full IDE-agent workflows."),
        "Project IDX" to CliCommand("Open idx.google.com in your browser.", "idx", "Google's web-based workspace with built-in Gemini coding assistance."),
        "Supermaven" to CliCommand("Install the Supermaven extension from your IDE Marketplace.", "Open IDE with Supermaven enabled", "An ultra-fast AI completion engine for VS Code, JetBrains, and Neovim."),
        "PyCharm AI" to CliCommand("Download PyCharm from jetbrains.com/pycharm", "pycharm .", "JetBrains Python IDE with integrated JetBrains AI Assistant."),
        "WebStorm AI" to CliCommand("Download WebStorm from jetbrains.com/webstorm", "webstorm .", "JetBrains JavaScript IDE with integrated JetBrains AI Assistant.")
    )

    data class CliCommand(val install: String, val launch: String, val note: String)

    private val rawCatalog = listOf(
        "Chatbots & LLMs" to listOf(
            "ChatGPT" to "https://chatgpt.com",
            "Claude.ai" to "https://claude.ai",
            "Gemini" to "https://gemini.google.com",
            "Microsoft Copilot" to "https://copilot.microsoft.com",
            "Perplexity.ai" to "https://www.perplexity.ai",
            "Grok.com" to "https://grok.com",
            "Meta AI" to "https://www.meta.ai",
            "Poe" to "https://poe.com",
            "You.com" to "https://you.com",
            "Pi" to "https://pi.ai",
            "DeepSeek" to "https://www.deepseek.com",
            "Mistral Le Chat" to "https://chat.mistral.ai",
            "HuggingChat" to "https://huggingface.co/chat",
            "Character.AI" to "https://character.ai",
            "Replika" to "https://replika.com",
            "Kimi" to "https://kimi.moonshot.cn",
            "Qwen Chat" to "https://chat.qwen.ai",
            "Phind" to "https://www.phind.com",
            "NotebookLM.google.com" to "https://notebooklm.google.com",
            "Consensus" to "https://consensus.app",
            "Elicit" to "https://elicit.com",
            "Scite" to "https://scite.ai",
            "Andi" to "https://andisearch.com",
            "Brave Leo" to "https://brave.com/leo",
            "Arc Max" to "https://arc.net/max",
            "Notebook LLM" to "https://notebooklm.google.com",
            "Cohere.ai" to "https://cohere.ai",
            "Godmode.space" to "https://godmode.space",
            "Harpa.ai" to "https://harpa.ai"
        ),
        "Coding Agents" to listOf(
            "VS Code" to "https://code.visualstudio.com",
            "Project IDX" to "https://idx.google.com",
            "Supermaven" to "https://supermaven.com",
            "PyCharm AI" to "https://www.jetbrains.com/pycharm",
            "WebStorm AI" to "https://www.jetbrains.com/webstorm",
            "OpenAI Codex" to "https://openai.com/blog/openai-codex",
            "Codex" to "https://openai.com/blog/openai-codex",
            "Claude Code" to "https://www.anthropic.com/claude-code",
            "Cursor.so" to "https://cursor.com",
            "Windsurf" to "https://windsurf.com",
            "GitHub Copilot" to "https://github.com/features/copilot",
            "Google Antigravity" to "https://antigravity.google",
            "Devin" to "https://devin.ai",
            "Replit.com" to "https://replit.com",
            "Bolt.new" to "https://bolt.new",
            "Lovable" to "https://lovable.dev",
            "v0" to "https://v0.dev",
            "Cline" to "https://cline.bot",
            "Roo Code" to "https://roocode.com",
            "Continue" to "https://www.continue.dev",
            "Aider" to "https://aider.chat",
            "Tabnine.com" to "https://www.tabnine.com",
            "Sourcegraph Cody" to "https://sourcegraph.com/cody",
            "Codeium" to "https://codeium.com",
            "Zed AI" to "https://zed.dev/ai",
            "JetBrains AI" to "https://www.jetbrains.com/ai",
            "Amazon Q Developer" to "https://aws.amazon.com/q/developer",
            "Gemini Code Assist" to "https://codeassist.google",
            "CodeRabbit" to "https://www.coderabbit.ai",
            "Sweep" to "https://sweep.dev",
            "PR-Agent" to "https://github.com/qodo-ai/pr-agent",
            "Blackbox.ai" to "https://www.blackbox.ai",
            "Mutable.ai" to "https://mutable.ai",
            "Pieces" to "https://pieces.app",
            "Warp AI" to "https://www.warp.dev",
            "Raycast AI" to "https://www.raycast.com/ai",
            "AutoGPT.net" to "https://autogpt.net",
            "Open Claw" to "https://openclaw.org",
            "Blink" to "https://blink.sh",
            "Gemini CLI" to "https://github.com/google/gemini-cli",
            "Bubble" to "https://bubble.io",
            "Runable" to "https://runable.com",
            "Netlify" to "https://netlify.com",
            "Prompt Layer" to "https://promptlayer.com",
            "Manus.im" to "https://manus.im"
        ),
        "Image & Design" to listOf(
            "Midjourney.com" to "https://www.midjourney.com",
            "Dall E" to "https://openai.com/dall-e",
            "Adobe Firefly" to "https://firefly.adobe.com",
            "Stable Diffusion" to "https://stability.ai",
            "Leonardo.ai" to "https://leonardo.ai",
            "Ideogram" to "https://ideogram.ai",
            "Recraft.ai" to "https://www.recraft.ai",
            "Canva.com" to "https://www.canva.com/ai",
            "Figma AI" to "https://www.figma.com/ai",
            "Krea AI" to "https://www.krea.ai",
            "Freepik AI" to "https://www.freepik.com/ai",
            "Playground AI" to "https://playground.com",
            "DreamStudio" to "https://dreamstudio.ai",
            "Clipdrop" to "https://clipdrop.co",
            "Magnific AI" to "https://magnific.ai",
            "Topaz Gigapixel" to "https://www.topazlabs.com/gigapixel",
            "Remove.bg" to "https://www.remove.bg",
            "Photoroom" to "https://www.photoroom.com",
            "Let's Enhance" to "https://letsenhance.io",
            "Luma Photon" to "https://lumalabs.ai/photon",
            "FLUX" to "https://blackforestlabs.ai",
            "NightCafe" to "https://nightcafe.studio",
            "Artbreeder" to "https://www.artbreeder.com",
            "Scenario" to "https://www.scenario.com",
            "Khroma" to "https://www.khroma.co",
            "Flair.ai" to "https://flair.ai",
            "Hotpot.ai" to "https://hotpot.ai",
            "Cleanup.pictures" to "https://cleanup.pictures",
            "FaceSwap.ai" to "https://faceswap.ai",
            "Fastphoto.io" to "https://fastphoto.io",
            "PicWish.com" to "https://picwish.com",
            "VanceAI.com" to "https://vanceai.com"
        ),
        "Video & Audio" to listOf(
            "Sora" to "https://openai.com/sora",
            "Runwayml.com" to "https://runwayml.com",
            "Pika" to "https://pika.art",
            "Luma Dream Machine" to "https://lumalabs.ai/dream-machine",
            "Kling AI" to "https://klingai.com",
            "Hailuo AI" to "https://hailuoai.video",
            "HeyGen.com" to "https://www.heygen.com",
            "Synthesia.io" to "https://www.synthesia.io",
            "Descript.com" to "https://www.descript.com",
            "Veo" to "https://deepmind.google/technologies/veo",
            "Captions" to "https://www.captions.ai",
            "Opus.pro" to "https://www.opus.pro",
            "Veed.io" to "https://www.veed.io",
            "Kapwing" to "https://www.kapwing.com",
            "InVideo AI" to "https://invideo.io/ai",
            "ElevenLabs.io" to "https://elevenlabs.io",
            "Suno.com" to "https://suno.com",
            "Udio" to "https://www.udio.com",
            "Riffusion.com" to "https://www.riffusion.com",
            "Murf.ai" to "https://murf.ai",
            "Play.ht" to "https://play.ht",
            "Resemble AI" to "https://www.resemble.ai",
            "WellSaid" to "https://wellsaidlabs.com",
            "Riverside" to "https://riverside.fm",
            "Adobe Podcast" to "https://podcast.adobe.com",
            "D-ID.com" to "https://www.d-id.com",
            "Pictory.ai" to "https://pictory.ai",
            "Fliki.ai" to "https://fliki.ai",
            "Gling.ai" to "https://gling.ai",
            "Wisecut.video" to "https://www.wisecut.video",
            "Clipchamp.com" to "https://clipchamp.com",
            "Lumen5.com" to "https://lumen5.com",
            "Steve.ai" to "https://www.steve.ai",
            "Synths.video" to "https://synths.video",
            "Soundraw.io" to "https://soundraw.io",
            "Boomy.com" to "https://boomy.com",
            "AIVA.ai" to "https://www.aiva.ai",
            "Beatoven.ai" to "https://www.beatoven.ai",
            "Mubert.com" to "https://mubert.com",
            "Sonantic.io" to "https://sonantic.io",
            "Speechelo.com" to "https://speechelo.com",
            "Speechify.com" to "https://speechify.com",
            "Krisp.ai" to "https://krisp.ai",
            "Capsho.com" to "https://capsho.com",
            "Zubtitle.com" to "https://zubtitle.com"
        ),
        "Productivity" to listOf(
            "Notion.so" to "https://notion.so",
            "Grammarly" to "https://www.grammarly.com",
            "Jasper.ai" to "https://www.jasper.ai",
            "Copy.ai" to "https://www.copy.ai",
            "Writer" to "https://writer.com",
            "Quillbot.com" to "https://quillbot.com",
            "Wordtune.com" to "https://www.wordtune.com",
            "Tome.app" to "https://tome.app",
            "Gamma.app" to "https://gamma.app",
            "Beautiful.ai" to "https://www.beautiful.ai",
            "Pitch" to "https://pitch.com",
            "SlidesAI.io" to "https://www.slidesai.io",
            "Mem" to "https://get.mem.ai",
            "Reflect" to "https://reflect.app",
            "Motion.so" to "https://www.usemotion.com",
            "Reclaim" to "https://reclaim.ai",
            "Clockwise" to "https://www.getclockwise.com",
            "Zapier AI" to "https://zapier.com/ai",
            "Make AI" to "https://www.make.com/en/ai",
            "Gumloop" to "https://www.gumloop.com",
            "Lindy" to "https://www.lindy.ai",
            "n8n" to "https://n8n.io",
            "Airtable.com" to "https://airtable.com",
            "Asana AI" to "https://asana.com/product/ai",
            "ClickUp.com" to "https://clickup.com",
            "monday AI" to "https://monday.com/features/ai",
            "Slack AI" to "https://slack.com/features/ai",
            "Zoom AI Companion" to "https://www.zoom.com/en/products/ai-assistant",
            "Microsoft 365 Copilot" to "https://www.microsoft.com/microsoft-365/copilot",
            "Gemini for Workspace" to "https://workspace.google.com/solutions/ai",
            "Superhuman.com" to "https://superhuman.com",
            "Fathom" to "https://fathom.video",
            "Fireflies.ai" to "https://fireflies.ai",
            "tl;dv" to "https://tldv.io",
            "Read.ai" to "https://www.read.ai",
            "MagicSlides.app" to "https://www.magicslides.app",
            "Otter.ai" to "https://otter.ai",
            "Taskade.com" to "https://www.taskade.com",
            "Personal.ai" to "https://www.personal.ai",
            "Typewise.app" to "https://typewise.app",
            "Compose.ai" to "https://www.compose.ai",
            "Cohesive.so" to "https://cohesive.so",
            "Outwrite.com" to "https://outwrite.com",
            "Obsidian" to "https://obsidian.md"
        ),
        "Research & Data" to listOf(
            "Excel Copilot" to "https://www.microsoft.com/microsoft-365/excel",
            "Julius" to "https://julius.ai",
            "DataCamp DataLab" to "https://www.datacamp.com/datalab",
            "Tableau Agent" to "https://www.tableau.com/products/tableau-agent",
            "Power BI Copilot" to "https://powerbi.microsoft.com",
            "Akkio" to "https://www.akkio.com",
            "Obviously AI" to "https://www.obviously.ai",
            "Rows AI" to "https://rows.com/ai",
            "Polymer" to "https://www.polymersearch.com",
            "Hex" to "https://hex.tech",
            "Deepnote AI" to "https://deepnote.com/ai",
            "Observable" to "https://observablehq.com",
            "Wolfram Alpha" to "https://www.wolframalpha.com",
            "Wolfram Notebook Assistant" to "https://www.wolfram.com/notebook-assistant",
            "AlphaSense" to "https://www.alpha-sense.com",
            "Hebbia" to "https://www.hebbia.ai",
            "Glean" to "https://www.glean.com",
            "Guru AI" to "https://www.getguru.com",
            "Harvey" to "https://www.harvey.ai",
            "CoCounsel" to "https://www.thomsonreuters.com/en/products-services/legal/cocounsel.html",
            "Casetext" to "https://casetext.com",
            "Lexis+ AI" to "https://www.lexisnexis.com/en-us/products/lexis-plus-ai.page",
            "DoNotPay" to "https://donotpay.com",
            "Legal Robot" to "https://legalrobot.com",
            "Kagi Assistant" to "https://kagi.com/assistant",
            "ChatPDF" to "https://www.chatpdf.com",
            "Humata" to "https://www.humata.ai",
            "AskYourPDF" to "https://askyourpdf.com",
            "Scholarcy" to "https://www.scholarcy.com",
            "SciSpace" to "https://scispace.com",
            "Semantic Scholar" to "https://www.semanticscholar.org",
            "ResearchRabbit" to "https://www.researchrabbit.ai",
            "Connected Papers" to "https://www.connectedpapers.com",
            "Litmaps" to "https://www.litmaps.com",
            "Feedly AI" to "https://feedly.com/i/ai",
            "Browse.ai" to "https://www.browse.ai",
            "WebPro" to "https://webpro.ai",
            "Tensor Flow" to "https://tensorflow.org",
            "Gradio" to "https://gradio.app"
        ),
        "Marketing & Sales" to listOf(
            "HubSpot Breeze" to "https://www.hubspot.com/products/artificial-intelligence",
            "Salesforce Einstein" to "https://www.salesforce.com/artificial-intelligence",
            "Intercom Fin" to "https://www.intercom.com/fin",
            "Zendesk AI" to "https://www.zendesk.com/ai",
            "Ada" to "https://www.ada.cx",
            "Drift" to "https://www.drift.com",
            "Gong" to "https://www.gong.io",
            "Clari" to "https://www.clari.com",
            "Lavender" to "https://www.lavender.ai",
            "Clay" to "https://www.clay.com",
            "Apollo AI" to "https://www.apollo.io",
            "Instantly AI" to "https://instantly.ai",
            "Customer.io AI" to "https://customer.io",
            "Mailchimp Intuit Assist" to "https://mailchimp.com/features/intuit-assist",
            "Hootsuite OwlyWriter" to "https://www.hootsuite.com/platform/owlywriter-ai",
            "Buffer AI Assistant" to "https://buffer.com/ai-assistant",
            "Sprout Social AI" to "https://sproutsocial.com/features/ai-social-media",
            "Semrush AI" to "https://www.semrush.com/features/ai",
            "SurferSEO.com" to "https://surferseo.com",
            "Frase.io" to "https://www.frase.io",
            "MarketMuse.com" to "https://www.marketmuse.com",
            "Clearscope" to "https://www.clearscope.io",
            "Adcreative.ai" to "https://www.adcreative.ai",
            "Anyword.com" to "https://anyword.com",
            "Predis.ai" to "https://predis.ai",
            "Writesonic.com" to "https://writesonic.com",
            "CopySmith.ai" to "https://copysmith.ai",
            "Hypotenuse.ai" to "https://www.hypotenuse.ai",
            "Peppertype.ai" to "https://www.peppertype.ai",
            "Scalenut.com" to "https://www.scalenut.com",
            "InkForAll.com" to "https://inkforall.com",
            "Creaitor.ai" to "https://www.creaitor.ai",
            "FunnelFreedom.io" to "https://funnelfreedom.io",
            "CopyMonkey.ai" to "https://copymonkey.ai",
            "Sociable.how" to "https://sociable.how",
            "Threadmaster.ai" to "https://threadmaster.ai",
            "Webinarkit.com" to "https://webinarkit.com",
            "Podium.page" to "https://podium.page"
        )
    )

    val list: List<Tool> = run {
        val seenNames = mutableSetOf<String>()
        rawCatalog.flatMapIndexed { catIdx, (category, tools) ->
            val profile = categoryProfiles[category] ?: Profile("#9fa8ff", "web", "AI tool.")
            val distinctTools = tools.filter { (name, _) ->
                val norm = name.lowercase()
                    .replace(Regex("\\.(com|ai|so|io|net|sh|bot|cx|cc|co|org|me|fm|us)\\b"), "")
                    .replace(".google.com", "")
                    .replace(".com", "")
                    .replace(".ai", "")
                    .replace(".so", "")
                    .replace(".io", "")
                    .replace("openai ", "")
                    .replace("google ", "")
                    .replace("microsoft ", "")
                    .replace("chat", "")
                    .replace("llm", "")
                    .replace("lm", "")
                    .replace(" ", "")
                    .replace("-", "")
                    .trim()
                if (norm.isEmpty()) {
                    true
                } else {
                    if (seenNames.contains(norm)) {
                        false
                    } else {
                        seenNames.add(norm)
                        true
                    }
                }
            }
            distinctTools.flatMapIndexed { itemIdx, (name, url) ->
                val idBase = name.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-')
                val cliCommand = cliCommands[name]
                val runtime = if (cliCommand != null) "cli" else profile.runtime
                val summary = cliCommand?.note ?: profile.summary
                
                val tags = mutableListOf(category.split(" ")[0].lowercase(), if (cliCommand != null) "installable" else "browser")
                if (listOf("ChatGPT", "Claude.ai", "Gemini", "Perplexity.ai", "Grok.com").contains(name)) {
                    tags.add("assistant")
                }
                if (listOf("OpenAI Codex", "Claude Code", "Cursor.so", "Windsurf", "Google Antigravity").contains(name)) {
                    tags.add("agent")
                }

                val baseTool = Tool(
                    id = idBase,
                    name = name,
                    url = url,
                    category = category,
                    summary = summary,
                    accent = profile.accent,
                    rank = catIdx * 1000 + itemIdx * 3 + 1,
                    runtime = runtime,
                    note = cliCommand?.launch ?: "",
                    tags = tags
                )

                val proSuffix = when (category) {
                    "Chatbots & LLMs" -> "Pro"
                    "Coding Agents" -> "Dev Edition"
                    "Image & Design" -> "Studio"
                    "Video & Audio" -> "Creator"
                    "Productivity" -> "Workspace"
                    "Research & Data" -> "Analyst"
                    else -> "Campaign"
                }
                val proUrl = if (url.endsWith("/")) "${url}pro" else "$url/pro"
                val proTool = Tool(
                    id = "$idBase-pro",
                    name = "$name $proSuffix",
                    url = proUrl,
                    category = category,
                    summary = "Enhanced version of $name with unlimited access, advanced model weights, and custom workflow presets.",
                    accent = profile.accent,
                    rank = catIdx * 1000 + itemIdx * 3 + 2,
                    runtime = runtime,
                    note = if (cliCommand != null) "${cliCommand.launch} --pro" else "",
                    tags = tags + listOf("premium", "pro")
                )
                
                listOf(baseTool, proTool)
            }
        }
    }
}
