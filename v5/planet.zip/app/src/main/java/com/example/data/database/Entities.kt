package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String,
    val name: String,
    val email: String,
    val passwordPlain: String // Using plain client-side storage for prototype sync
)

@Entity(
    tableName = "installed_tools",
    primaryKeys = ["userId", "toolId"]
)
data class InstalledToolEntity(
    val userId: String,
    val toolId: String,
    val installedAt: Long
)

@Entity(tableName = "user_notes")
data class UserNoteEntity(
    @PrimaryKey val userId: String,
    val notesText: String,
    val updatedAt: Long
)

@Entity(tableName = "analytics_logs")
data class AnalyticsLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String,
    val toolId: String,
    val toolName: String,
    val category: String,
    val timestamp: Long,
    val dateString: String // yyyy-MM-dd
)
