package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.Catalog
import com.example.data.Tool
import com.example.data.database.AnalyticsLogEntity
import com.example.data.database.PlanetDatabase
import com.example.data.database.UserEntity
import com.example.data.repository.PlanetRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class PlanetViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: PlanetRepository
    private val prefs = application.getSharedPreferences("planet_prefs", Context.MODE_PRIVATE)

    // Splash screen state: true = showing splash screen
    private val _showSplash = MutableStateFlow(true)
    val showSplash: StateFlow<Boolean> = _showSplash.asStateFlow()

    init {
        val database = PlanetDatabase.getDatabase(application)
        repository = PlanetRepository(database.planetDao())
        
        // Hide the splash screen after 2.2 seconds (2200ms) with a sleek fade transition
        viewModelScope.launch {
            kotlinx.coroutines.delay(2200)
            _showSplash.value = false
        }

        // Initialize defaults for guest profile so they start with applications out-of-the-box
        viewModelScope.launch {
            try {
                val guestTools = repository.getInstalledToolsForUser("guest").first()
                if (guestTools.isEmpty()) {
                    repository.installDefaultTools("guest")
                }
            } catch (e: Exception) {
                // Ignore transient db errors on startup
            }
        }
    }

    // Active View Tab: "home" | "store" | "workspace" | "analytics" | "manage"
    private val _activeView = MutableStateFlow("home")
    val activeView: StateFlow<String> = _activeView.asStateFlow()

    // Current User Session (null for guest mode, or UserEntity)
    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser: StateFlow<UserEntity?> = _currentUser.asStateFlow()

    // Auth status messages
    private val _authMessage = MutableStateFlow<Pair<String, String>?>(null) // Pair(Message, Type/Tone: "success" | "error" | "neutral")
    val authMessage: StateFlow<Pair<String, String>?> = _authMessage.asStateFlow()

    // Active Context: "all" | "work" | "creative" | "study"
    private val _activeContext = MutableStateFlow(
        application.getSharedPreferences("planet_prefs", Context.MODE_PRIVATE).getString("active_context", "all") ?: "all"
    )
    val activeContext: StateFlow<String> = _activeContext.asStateFlow()

    // Marketplace states
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("all")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _selectedSort = MutableStateFlow("popular") // "popular" | "az" | "runtime"
    val selectedSort: StateFlow<String> = _selectedSort.asStateFlow()

    // Workspace states
    private val _leftPaneToolId = MutableStateFlow<String?>(null)
    val leftPaneToolId: StateFlow<String?> = _leftPaneToolId.asStateFlow()

    private val _rightPaneToolId = MutableStateFlow<String?>(null)
    val rightPaneToolId: StateFlow<String?> = _rightPaneToolId.asStateFlow()

    private val _isWorkspaceLaunched = MutableStateFlow(false)
    val isWorkspaceLaunched: StateFlow<Boolean> = _isWorkspaceLaunched.asStateFlow()

    // Theme settings: true = Dark Theme, false = Light Theme
    private val _isDarkTheme = MutableStateFlow(true)
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    fun toggleTheme() {
        _isDarkTheme.value = !_isDarkTheme.value
    }

    // Selected Tool for details dialog
    private val _selectedToolForDetails = MutableStateFlow<Tool?>(null)
    val selectedToolForDetails: StateFlow<Tool?> = _selectedToolForDetails.asStateFlow()

    // Retrieve active user ID helper
    private val activeUserId: String
        get() = _currentUser.value?.id ?: "guest"

    // Dynamic stream of installed tools for currently logged-in user
    @OptIn(ExperimentalCoroutinesApi::class)
    val installedTools: StateFlow<List<Tool>> = _currentUser
        .flatMapLatest { user ->
            val uId = user?.id ?: "guest"
            repository.getInstalledToolsForUser(uId).map { entities ->
                entities.mapNotNull { entity ->
                    val canonicalId = when (entity.toolId) {
                        "claude" -> "claude-ai"
                        "perplexity" -> "perplexity-ai"
                        "grok" -> "grok-com"
                        "notebooklm" -> "notebooklm-google-com"
                        else -> entity.toolId
                    }
                    Catalog.list.find { it.id == canonicalId }
                }
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Dynamic stream of user notes for currently logged-in user
    @OptIn(ExperimentalCoroutinesApi::class)
    val userNotes: StateFlow<String> = _currentUser
        .flatMapLatest { user ->
            val uId = user?.id ?: "guest"
            repository.getNotesForUser(uId).map { entity ->
                entity?.notesText ?: ""
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = ""
        )

    // Dynamic stream of analytics logs
    @OptIn(ExperimentalCoroutinesApi::class)
    val analyticsLogs: StateFlow<List<AnalyticsLogEntity>> = _currentUser
        .flatMapLatest { user ->
            val uId = user?.id ?: "guest"
            repository.getAnalyticsLogsForUser(uId)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Filtered static catalog based on query, category & context
    val filteredMarketplaceTools: StateFlow<List<Tool>> = combine(
        _searchQuery, _selectedCategory, _selectedSort, _activeContext
    ) { query, category, sort, context ->
        var list = Catalog.list.filter { tool ->
            val matchesQuery = query.isBlank() || 
                tool.name.contains(query, ignoreCase = true) ||
                tool.category.contains(query, ignoreCase = true) ||
                tool.summary.contains(query, ignoreCase = true) ||
                tool.tags.any { it.contains(query, ignoreCase = true) }
            
            val matchesCategory = category == "all" || tool.category.equals(category, ignoreCase = true)
            matchesQuery && matchesCategory
        }

        // Apply sorting
        list = when (sort) {
            "az" -> list.sortedBy { it.name }
            "runtime" -> list.sortedBy { it.runtime }
            else -> list.sortedBy { it.rank } // Popularity index rank
        }

        // Apply context recommendation prioritization (bubble context tools to top if context isn't 'all')
        if (context != "all") {
            val relevantCategories = when (context) {
                "work" -> listSetOfWork()
                "creative" -> listSetOfCreative()
                "study" -> listSetOfStudy()
                else -> emptyList()
            }
            list = list.sortedWith(
                compareBy<Tool> { !relevantCategories.contains(it.category) }
                    .thenBy { it.rank }
            )
        }

        list
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Catalog.list)

    private fun listSetOfWork() = listOf("Productivity", "Research & Data", "Marketing & Sales", "Coding Agents")
    private fun listSetOfCreative() = listOf("Image & Design", "Video & Audio", "Chatbots & LLMs")
    private fun listSetOfStudy() = listOf("Research & Data", "Chatbots & LLMs", "Productivity")

    // View Changer
    fun switchView(view: String) {
        _activeView.value = view
        clearAuthMessage()
    }

    // Context Changer
    fun switchContext(context: String) {
        _activeContext.value = context
        prefs.edit().putString("active_context", context).apply()
    }

    // Search and filters
    fun updateQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateCategory(category: String) {
        _selectedCategory.value = category
    }

    fun updateSort(sort: String) {
        _selectedSort.value = sort
    }

    // Workspace Handlers
    fun setLeftPaneTool(toolId: String?) {
        _leftPaneToolId.value = toolId
    }

    fun setRightPaneTool(toolId: String?) {
        _rightPaneToolId.value = toolId
    }

    fun launchWorkspace() {
        if (_leftPaneToolId.value != null || _rightPaneToolId.value != null) {
            _isWorkspaceLaunched.value = true
        }
    }

    fun resetWorkspace() {
        _isWorkspaceLaunched.value = false
        _leftPaneToolId.value = null
        _rightPaneToolId.value = null
    }

    // Modal view details
    fun showToolDetails(tool: Tool?) {
        _selectedToolForDetails.value = tool
    }

    // Account Actions
    fun signUp(name: String, email: String, passwordPlain: String) {
        if (name.isBlank() || email.isBlank() || passwordPlain.isBlank()) {
            _authMessage.value = Pair("Please complete all fields.", "error")
            return
        }
        if (passwordPlain.length < 6) {
            _authMessage.value = Pair("Password must be at least 6 characters.", "error")
            return
        }

        viewModelScope.launch {
            val normalizedEmail = email.trim().lowercase()
            val existing = repository.getUserByEmail(normalizedEmail)
            if (existing != null) {
                _authMessage.value = Pair("An account with this email already exists.", "error")
                return@launch
            }

            val userId = "user-${System.currentTimeMillis()}-${(1000..9999).random()}"
            val newUser = UserEntity(userId, name.trim(), normalizedEmail, passwordPlain)
            repository.insertUser(newUser)
            
            // Migrate any tools/notes added as guest to the new user ID
            repository.migrateGuestToolsAndNotes("guest", userId)
            
            val welcomeNotes = """Welcome to Planet, ${newUser.name}!
                |
                |Your personal Launchpad is ready. We've synchronized your guest applications to your profile.
                |
                |- [ ] Explore the Marketplace to find more tools.
                |- [ ] Use this notepad to keep track of your prompts, ideas, and tasks.
                |- [ ] Launch tools directly from your Launchpad.
            """.trimMargin()
            
            val currentNotes = repository.getNotesForUser(userId).first()
            if (currentNotes == null || currentNotes.notesText.isBlank()) {
                repository.updateNotes(userId, welcomeNotes)
            }

            _currentUser.value = newUser
            _authMessage.value = Pair("Account created! Guest tools integrated.", "success")
        }
    }

    fun signIn(email: String, passwordPlain: String) {
        if (email.isBlank() || passwordPlain.isBlank()) {
            _authMessage.value = Pair("Please enter your credentials.", "error")
            return
        }

        viewModelScope.launch {
            val normalizedEmail = email.trim().lowercase()
            val user = repository.getUserByEmail(normalizedEmail)
            if (user == null || user.passwordPlain != passwordPlain) {
                _authMessage.value = Pair("Incorrect email or password.", "error")
                return@launch
            }

            // Sync/merge guest tools/notes to the existing user profile
            repository.migrateGuestToolsAndNotes("guest", user.id)

            _currentUser.value = user
            _authMessage.value = Pair("Welcome back, ${user.name}!", "success")
        }
    }

    fun signOut() {
        _currentUser.value = null
        _authMessage.value = Pair("Signed out.", "success")
        resetWorkspace()
    }

    fun clearAuthMessage() {
        _authMessage.value = null
    }

    // Notepad Saver
    fun updateNotes(text: String) {
        viewModelScope.launch {
            repository.updateNotes(activeUserId, text)
        }
    }

    // Tool Management Installer
    fun installTool(tool: Tool) {
        viewModelScope.launch {
            if (installedTools.value.any { it.id == tool.id }) return@launch
            repository.installTool(activeUserId, tool.id)
            _authMessage.value = Pair("Installed ${tool.name} successfully!", "success")
        }
    }

    fun removeTool(tool: Tool) {
        viewModelScope.launch {
            repository.removeTool(activeUserId, tool.id)
            if (_leftPaneToolId.value == tool.id) _leftPaneToolId.value = null
            if (_rightPaneToolId.value == tool.id) _rightPaneToolId.value = null
            _authMessage.value = Pair("Removed ${tool.name}.", "success")
        }
    }

    fun resetAllInstalls() {
        viewModelScope.launch {
            repository.clearInstalledTools(activeUserId)
            resetWorkspace()
            _authMessage.value = Pair("Reset all installed tools.", "success")
        }
    }

    // Launch recorder
    fun recordToolLaunch(tool: Tool) {
        viewModelScope.launch {
            repository.logToolLaunch(activeUserId, tool.id, tool.name, tool.category)
        }
    }

    fun resetAnalytics() {
        viewModelScope.launch {
            repository.clearAnalyticsLogs(activeUserId)
        }
    }
}
