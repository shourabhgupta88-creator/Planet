package com.example.data.repository

import com.example.data.database.AnalyticsLogEntity
import com.example.data.database.InstalledToolEntity
import com.example.data.database.PlanetDao
import com.example.data.database.UserEntity
import com.example.data.database.UserNoteEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class PlanetRepository(private val planetDao: PlanetDao) {

    // Users
    suspend fun getUserByEmail(email: String): UserEntity? {
        return planetDao.getUserByEmail(email)
    }

    suspend fun insertUser(user: UserEntity) {
        planetDao.insertUser(user)
    }

    // Installed Tools
    fun getInstalledToolsForUser(userId: String): Flow<List<InstalledToolEntity>> {
        return planetDao.getInstalledToolsForUser(userId)
    }

    suspend fun installTool(userId: String, toolId: String) {
        planetDao.insertInstalledTool(
            InstalledToolEntity(
                userId = userId,
                toolId = toolId,
                installedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun installDefaultTools(userId: String) {
        val now = System.currentTimeMillis()
        val defaults = listOf("chatgpt", "claude-ai", "gemini").map { toolId ->
            InstalledToolEntity(userId = userId, toolId = toolId, installedAt = now)
        }
        planetDao.insertInstalledTools(defaults)
    }

    suspend fun migrateGuestToolsAndNotes(guestUserId: String, targetUserId: String) {
        // 1. Migrate installed tools
        val guestTools = planetDao.getInstalledToolsForUser(guestUserId).first()
        if (guestTools.isNotEmpty()) {
            val migratedTools = guestTools.map {
                it.copy(userId = targetUserId, installedAt = System.currentTimeMillis())
            }
            planetDao.insertInstalledTools(migratedTools)
            planetDao.clearInstalledTools(guestUserId)
        } else {
            // Check if target user has any tools. If not, install defaults for them.
            val targetTools = planetDao.getInstalledToolsForUser(targetUserId).first()
            if (targetTools.isEmpty()) {
                installDefaultTools(targetUserId)
            }
        }

        // 2. Migrate notes
        val guestNotes = planetDao.getNotesForUser(guestUserId).first()
        if (guestNotes != null && guestNotes.notesText.isNotBlank()) {
            val existingTargetNotes = planetDao.getNotesForUser(targetUserId).first()
            if (existingTargetNotes == null || existingTargetNotes.notesText.isBlank()) {
                planetDao.insertOrUpdateNotes(
                    UserNoteEntity(
                        userId = targetUserId,
                        notesText = guestNotes.notesText,
                        updatedAt = System.currentTimeMillis()
                    )
                )
            } else if (existingTargetNotes.notesText != guestNotes.notesText) {
                // Merge notes text
                val mergedNotes = existingTargetNotes.notesText + "\n\n--- Migrated Guest Notes ---\n" + guestNotes.notesText
                planetDao.insertOrUpdateNotes(
                    UserNoteEntity(
                        userId = targetUserId,
                        notesText = mergedNotes,
                        updatedAt = System.currentTimeMillis()
                    )
                )
            }
            // Clear guest notes
            planetDao.insertOrUpdateNotes(
                UserNoteEntity(
                    userId = guestUserId,
                    notesText = "",
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    suspend fun removeTool(userId: String, toolId: String) {
        planetDao.deleteInstalledTool(userId, toolId)
    }

    suspend fun clearInstalledTools(userId: String) {
        planetDao.clearInstalledTools(userId)
    }

    // Notes
    fun getNotesForUser(userId: String): Flow<UserNoteEntity?> {
        return planetDao.getNotesForUser(userId)
    }

    suspend fun updateNotes(userId: String, text: String) {
        planetDao.insertOrUpdateNotes(
            UserNoteEntity(
                userId = userId,
                notesText = text,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    // Analytics
    fun getAnalyticsLogsForUser(userId: String): Flow<List<AnalyticsLogEntity>> {
        return planetDao.getAnalyticsLogsForUser(userId)
    }

    suspend fun logToolLaunch(userId: String, toolId: String, toolName: String, category: String) {
        val now = System.currentTimeMillis()
        // Simple helper to generate format (yyyy-MM-dd)
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        val dateStr = sdf.format(java.util.Date(now))
        
        planetDao.insertAnalyticsLog(
            AnalyticsLogEntity(
                userId = userId,
                toolId = toolId,
                toolName = toolName,
                category = category,
                timestamp = now,
                dateString = dateStr
            )
        )
    }

    suspend fun clearAnalyticsLogs(userId: String) {
        planetDao.clearAnalyticsLogs(userId)
    }
}
