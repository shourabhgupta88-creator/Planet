package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.animation.core.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.Catalog
import com.example.data.Tool
import com.example.data.database.AnalyticsLogEntity
import com.example.ui.PlanetViewModel
import com.example.ui.theme.*
import java.util.*

// Main layout that resolves current active view
@Composable
fun PlanetAppContent(viewModel: PlanetViewModel) {
    val activeView by viewModel.activeView.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val authMessage by viewModel.authMessage.collectAsStateWithLifecycle()
    val selectedToolForDetails by viewModel.selectedToolForDetails.collectAsStateWithLifecycle()
    val showSplash by viewModel.showSplash.collectAsStateWithLifecycle()
    val isDark = isSystemInDarkTheme()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Space Background Image of majestic galaxy starfields matching the uploaded photo
        AsyncImage(
            model = coil.request.ImageRequest.Builder(LocalContext.current)
                .data(com.example.R.drawable.space_background_1779438904548)
                .crossfade(true)
                .build(),
            contentDescription = "Cosmic Space Background",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // Semi-transparent overlay to ensure extreme readability & elegant contrast
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    if (isDark) Color.Black.copy(alpha = 0.55f)
                    else Color.White.copy(alpha = 0.78f)
                )
        )

        Column(modifier = Modifier.fillMaxSize()) {
            HeaderBar(viewModel)
            
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (activeView) {
                    "home" -> HomeScreen(viewModel)
                    "store" -> MarketplaceScreen(viewModel)
                    "workspace" -> WorkspaceScreen(viewModel)
                    "analytics" -> AnalyticsScreen(viewModel)
                    "manage" -> ManageScreen(viewModel)
                }
            }

            BottomNavBar(viewModel)
        }

        // Floating info messages/toasts
        authMessage?.let { (msg, type) ->
            val context = LocalContext.current
            LaunchedEffect(msg) {
                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                viewModel.clearAuthMessage()
            }
        }

        // Details dialog
        selectedToolForDetails?.let { tool ->
            ToolDetailsDialog(tool = tool, viewModel = viewModel, onDismiss = { viewModel.showToolDetails(null) })
        }

        // Beautiful Black Background Splash Screen overlay with custom generated Planet Logo
        AnimatedVisibility(
            visible = showSplash,
            enter = fadeIn(animationSpec = tween(500)),
            exit = fadeOut(animationSpec = tween(600))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    // Pulsing scale float animation
                    val infiniteTransition = rememberInfiniteTransition(label = "planet_pulse")
                    val scale by infiniteTransition.animateFloat(
                        initialValue = 0.95f,
                        targetValue = 1.05f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(1300, easing = FastOutSlowInEasing),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "logo_scale"
                    )

                    // Majestic generated circular planet logo
                    AsyncImage(
                        model = coil.request.ImageRequest.Builder(LocalContext.current)
                            .data(com.example.R.drawable.img_planet_logo_1779947239757)
                            .crossfade(true)
                            .build(),
                        contentDescription = "Planet Logo",
                        modifier = Modifier
                            .size(170.dp)
                            .clip(CircleShape)
                            .scale(scale)
                            .border(1.5.dp, Color.White.copy(alpha = 0.18f), CircleShape)
                    )

                    Spacer(modifier = Modifier.height(28.dp))

                    // "Planet" Display Heading
                    Text(
                        text = "Planet",
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            letterSpacing = 1.2.sp
                        ),
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Subtitle "The AI applications desk"
                    Text(
                        text = "The AI applications desk",
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontWeight = FontWeight.Normal,
                            color = Color.White.copy(alpha = 0.6f),
                            letterSpacing = 0.5.sp
                        ),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HeaderBar(viewModel: PlanetViewModel) {
    val activeContext by viewModel.activeContext.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val isDark = isSystemInDarkTheme()

    val greeting = remember {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        when (hour) {
            in 0..11 -> "Good morning"
            in 12..16 -> "Good afternoon"
            else -> "Good evening"
        }
    }

    Surface(
        color = (if (isDark) MaterialTheme.colorScheme.surface else Color.White).copy(alpha = 0.82f),
        tonalElevation = 2.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .statusBarsPadding()
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "$greeting,",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText
                )
                Text(
                    text = currentUser?.name ?: "Guest Explorer",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = if (isDark) Color.White else BentoTextDark,
                    letterSpacing = (-0.5).sp
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                var contextMenuExpanded by remember { mutableStateOf(false) }

                Box {
                    AssistChip(
                        onClick = { contextMenuExpanded = true },
                        label = { 
                            val label = when (activeContext) {
                                "work" -> "💼 Work"
                                "creative" -> "🎨 Creative"
                                "study" -> "📚 Study"
                                else -> "🌐 All"
                            }
                            Text(label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) 
                        },
                        shape = RoundedCornerShape(14.dp),
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant else BentoLilac,
                            labelColor = if (isDark) Color.White else BentoTextDark
                        ),
                        border = BorderStroke(1.dp, if (isDark) Color.Transparent else BentoBorder),
                        trailingIcon = { Icon(Icons.Filled.ArrowDropDown, contentDescription = null, modifier = Modifier.size(14.dp)) }
                    )

                    DropdownMenu(
                        expanded = contextMenuExpanded,
                        onDismissRequest = { contextMenuExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("🌐 All Contexts") },
                            onClick = {
                                viewModel.switchContext("all")
                                contextMenuExpanded = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("💼 Work Context") },
                            onClick = {
                                viewModel.switchContext("work")
                                contextMenuExpanded = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("🎨 Creative Context") },
                            onClick = {
                                viewModel.switchContext("creative")
                                contextMenuExpanded = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("📚 Study Context") },
                            onClick = {
                                viewModel.switchContext("study")
                                contextMenuExpanded = false
                            }
                        )
                    }
                }
                Spacer(modifier = Modifier.width(10.dp))

                // Light Mode / Dark Mode Toggle
                IconButton(
                    onClick = { viewModel.toggleTheme() },
                    modifier = Modifier
                        .size(40.dp)
                        .background(
                            if (isDark) Color.White.copy(alpha = 0.12f) 
                            else Color.Black.copy(alpha = 0.06f),
                            CircleShape
                        )
                ) {
                    Icon(
                        imageVector = if (isDark) Icons.Filled.WbSunny else Icons.Filled.NightsStay,
                        contentDescription = if (isDark) "Switch to Light Mode" else "Switch to Dark Mode",
                        tint = if (isDark) Color(0xFFFFD700) else Color(0xFF5B507A),
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))
                
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(if (isDark) MaterialTheme.colorScheme.primaryContainer else BentoLavender)
                        .border(1.5.dp, Color.White, CircleShape)
                        .clickable { viewModel.switchView("home") } 
                ) {
                    val initials = if (currentUser != null) {
                        currentUser!!.name.take(2).uppercase()
                    } else {
                        "GE"
                    }
                    Text(
                        text = initials,
                        color = if (isDark) Color.White else BentoTextDark,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
    }
}

@Composable
fun BottomNavBar(viewModel: PlanetViewModel) {
    val activeView by viewModel.activeView.collectAsStateWithLifecycle()
    val isDark = isSystemInDarkTheme()

    NavigationBar(
        tonalElevation = 8.dp,
        containerColor = (if (isDark) MaterialTheme.colorScheme.surface else Color(0xFFF7F2F9)).copy(alpha = 0.85f),
        modifier = Modifier.fillMaxWidth()
    ) {
        val tabs = listOf(
            Triple("home", "Launchpad", Icons.Filled.Home),
            Triple("store", "Marketplace", Icons.Filled.Storefront),
            Triple("workspace", "Workspace", Icons.Filled.Dashboard),
            Triple("analytics", "Analytics", Icons.Filled.BarChart),
            Triple("manage", "Manage", Icons.Filled.Settings)
        )

        tabs.forEach { (viewName, label, icon) ->
            NavigationBarItem(
                selected = activeView == viewName,
                onClick = { viewModel.switchView(viewName) },
                icon = { Icon(icon, contentDescription = label) },
                label = { Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                alwaysShowLabel = true,
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = if (isDark) Color.Black else BentoTextDark,
                    selectedTextColor = if (isDark) Color.White else BentoTextDark,
                    indicatorColor = if (isDark) MaterialTheme.colorScheme.primary else BentoLavender,
                    unselectedIconColor = if (isDark) Color.White.copy(alpha = 0.5f) else BentoSubText,
                    unselectedTextColor = if (isDark) Color.White.copy(alpha = 0.5f) else BentoSubText
                )
            )
        }
    }
}

// ---------------------------------------------
// HOME SCREEN (Launchpad, Notes, Auth Account)
// ---------------------------------------------
@Composable
fun HomeScreen(viewModel: PlanetViewModel) {
    val installedTools by viewModel.installedTools.collectAsStateWithLifecycle()
    val activeContext by viewModel.activeContext.collectAsStateWithLifecycle()
    val scrollState = rememberScrollState()
    val isDark = isSystemInDarkTheme()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Hero Card (Bento Style)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant else BentoLavender
            ),
            border = BorderStroke(1.dp, if (isDark) Color.Transparent else BentoBorder)
        ) {
            Column(modifier = Modifier.padding(22.dp)) {
                Text(
                    text = "A modern dashboard for the AI tools you actually use.",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold,
                    lineHeight = 26.sp,
                    color = if (isDark) Color.White else BentoTextDark
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Zero prompt fluff. Install AI applications from the marketplace, then open them as desktop web apps, sandbox sessions, or launch helpers.",
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                    color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText
                )

                Spacer(modifier = Modifier.height(18.dp))
                Text(
                    text = "Filter Launchpad Workspace context:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = if (isDark) Color.White else BentoTextDark
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val contexts = listOf(
                        Pair("all", "🌐 All"),
                        Pair("work", "💼 Work"),
                        Pair("creative", "🎨 Create"),
                        Pair("study", "📚 Study")
                    )
                    contexts.forEach { (key, name) ->
                        FilterChip(
                            selected = activeContext == key,
                            onClick = { viewModel.switchContext(key) },
                            label = { Text(name, fontSize = 11.sp) },
                            shape = RoundedCornerShape(16.dp)
                        )
                    }
                }
            }
        }

        // Installed Apps Launchpad Section
        Text(
            text = "Your Launchpad (${installedTools.size} apps)",
            fontSize = 18.sp,
            fontWeight = FontWeight.ExtraBold,
            color = if (isDark) Color.White else BentoTextDark,
            modifier = Modifier.padding(vertical = 8.dp)
        )

        val relevantCategories = when (activeContext) {
            "work" -> listOf("Productivity", "Research & Data", "Marketing & Sales", "Coding Agents")
            "creative" -> listOf("Image & Design", "Video & Audio", "Chatbots & LLMs")
            "study" -> listOf("Research & Data", "Chatbots & LLMs", "Productivity")
            else -> null
        }
        val displayedInstalled = if (relevantCategories != null) {
            installedTools.filter { relevantCategories.contains(it.category) }
        } else {
            installedTools
        }

        if (displayedInstalled.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .border(
                        1.dp, 
                        if (isDark) Color.Transparent else BentoBorder, 
                        RoundedCornerShape(28.dp)
                    )
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                    .clickable { viewModel.switchView("store") }
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Filled.Storefront,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (installedTools.isEmpty()) "No launchers installed yet" else "No applications match '$activeContext'",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp,
                        color = if (isDark) Color.White else BentoTextDark
                    )
                    Text(
                        text = if (installedTools.isEmpty()) "Find and add tools via the Marketplace Tab" else "Switch context filter or browse complete launchpad",
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText
                    )
                }
            }
        } else {
            val chunked = displayedInstalled.chunked(2)
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                chunked.forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        rowItems.forEachIndexed { index, tool ->
                            Box(modifier = Modifier.weight(1f)) {
                                BentoToolCard(tool = tool, viewModel = viewModel, index = index)
                            }
                        }
                        if (rowItems.size < 2) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        NotepadPanel(viewModel)

        Spacer(modifier = Modifier.height(24.dp))

        AccountPanel(viewModel)
    }
}

fun launchOrDownloadTool(context: android.content.Context, tool: Tool, viewModel: PlanetViewModel) {
    viewModel.recordToolLaunch(tool)
    
    val packageName = tool.getAndroidPackageName()
    if (packageName != null) {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            try {
                context.startActivity(launchIntent)
                Toast.makeText(context, "Opening ${tool.name} app on phone...", Toast.LENGTH_SHORT).show()
                return
            } catch (e: Exception) {
                // Fall back to download
            }
        }
    }
    
    val downloadUrl = tool.getDownloadUrl()
    try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(downloadUrl))
        context.startActivity(intent)
        Toast.makeText(context, "Opening download link for ${tool.name}...", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Toast.makeText(context, "Cannot open download link: $downloadUrl", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun BentoToolCard(tool: Tool, viewModel: PlanetViewModel, index: Int) {
    val context = LocalContext.current
    val isDark = isSystemInDarkTheme()
    
    val pastelBgs = listOf(BentoBlue, BentoLavender, BentoPink, BentoLilac)
    val cardBg = if (isDark) {
        MaterialTheme.colorScheme.surfaceVariant
    } else {
        pastelBgs[index % pastelBgs.size]
    }
    
    var color = remember(tool.accent) {
        try { Color(android.graphics.Color.parseColor(tool.accent)) } catch (e: Exception) { SpaceYellowAccent }
    }

    val isAppInstalled = remember(tool) {
        val pkg = tool.getAndroidPackageName()
        if (pkg != null) {
            try {
                context.packageManager.getLaunchIntentForPackage(pkg) != null
            } catch (e: Exception) {
                false
            }
        } else {
            false
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .clickable {
                launchOrDownloadTool(context, tool, viewModel)
            },
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = cardBg),
        border = BorderStroke(1.dp, if (isDark) Color.Transparent else BentoBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = tool.category.take(13),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText,
                        maxLines = 1,
                        modifier = Modifier
                            .background(
                                color = (if (isDark) Color.Black else Color.White).copy(alpha = 0.47f),
                                shape = CircleShape
                            )
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                    
                    Icon(
                        Icons.Filled.Info,
                        contentDescription = "Details",
                        tint = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoTextDark.copy(alpha = 0.5f),
                        modifier = Modifier
                            .size(16.dp)
                            .clickable { viewModel.showToolDetails(tool) }
                    )
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background((if (isDark) Color.Black else Color.White).copy(alpha = 0.65f))
                    ) {
                        Text(
                            text = tool.name.take(2).uppercase(Locale.getDefault()),
                            fontWeight = FontWeight.ExtraBold,
                            color = color,
                            fontSize = 12.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = tool.name,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp,
                        maxLines = 2,
                        lineHeight = 15.sp,
                        color = if (isDark) Color.White else BentoTextDark
                    )
                }
            }
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = tool.runtime.uppercase(Locale.getDefault()),
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Black,
                    color = if (isDark) Color.White else BentoTextDark,
                    modifier = Modifier
                        .background(
                            (if (isDark) MaterialTheme.colorScheme.primaryContainer else Color.White).copy(alpha = 0.5f),
                            shape = RoundedCornerShape(5.dp)
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
                
                Button(
                    onClick = {
                        launchOrDownloadTool(context, tool, viewModel)
                    },
                    modifier = Modifier.height(28.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isDark) MaterialTheme.colorScheme.primary else BentoPurpleAccent,
                        contentColor = Color.White
                    )
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isAppInstalled) "Open App" else if (tool.runtime == "cli") "Download" else "Download ↗",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Icon(
                            if (isAppInstalled) Icons.Filled.PlayArrow else Icons.Filled.ArrowDownward,
                            contentDescription = null,
                            modifier = Modifier.size(9.dp),
                            tint = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun NotepadPanel(viewModel: PlanetViewModel) {
    val notesText by viewModel.userNotes.collectAsStateWithLifecycle()
    var unsavedText by remember(notesText) { mutableStateOf(notesText) }
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current
    val isDark = isSystemInDarkTheme()

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant else BentoPink
        ),
        border = BorderStroke(1.dp, if (isDark) Color.Transparent else BentoBorder)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Quick Notes / Prompts",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.sp,
                        color = if (isDark) Color.White else BentoTextDark
                    )
                    Text(
                        text = "Autosaves locally to sandbox",
                        fontSize = 11.sp,
                        color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    IconButton(
                        onClick = {
                            clipboardManager.setText(AnnotatedString(unsavedText))
                            Toast.makeText(context, "Copied notes to clipboard", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .background(
                                color = (if (isDark) Color.Black else Color.White).copy(alpha = 0.5f),
                                shape = CircleShape
                            )
                    ) {
                        Icon(
                            Icons.Filled.ContentCopy, 
                            contentDescription = "Copy text", 
                            modifier = Modifier.size(16.dp),
                            tint = if (isDark) Color.White else BentoTextDark
                        )
                    }
                    IconButton(
                        onClick = {
                            unsavedText = ""
                            viewModel.updateNotes("")
                            Toast.makeText(context, "Notes cleared", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .background(
                                color = (if (isDark) Color.Black else Color.White).copy(alpha = 0.5f),
                                shape = CircleShape
                            )
                    ) {
                        Icon(
                            Icons.Filled.Delete, 
                            contentDescription = "Clear notes", 
                            modifier = Modifier.size(16.dp),
                            tint = if (isDark) Color.White else BentoTextDark
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = unsavedText,
                onValueChange = {
                    unsavedText = it
                    viewModel.updateNotes(it)
                },
                placeholder = { Text("Write prompts, keys, lists, or custom meeting notes that you want to remember...", fontSize = 13.sp) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
                textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = if (isDark) Color.White else BentoTextDark),
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = (if (isDark) Color.Black else Color.White).copy(alpha = 0.4f),
                    unfocusedContainerColor = (if (isDark) Color.Black else Color.White).copy(alpha = 0.25f),
                    focusedBorderColor = if (isDark) MaterialTheme.colorScheme.primary else BentoPurpleAccent,
                    unfocusedBorderColor = if (isDark) Color.White.copy(alpha = 0.12f) else BentoBorder.copy(alpha = 0.5f)
                )
            )

            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Ctrl/Cmd shortcuts active",
                    fontSize = 10.sp,
                    color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText,
                    fontWeight = FontWeight.Medium
                )
                
                Button(
                    onClick = {
                        try {
                            val shareIntent = Intent().apply {
                                action = Intent.ACTION_SEND
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, unsavedText)
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Save notes as TXT"))
                        } catch (e: Exception) {
                            Toast.makeText(context, "Share error", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.height(30.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(15.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isDark) MaterialTheme.colorScheme.primary else BentoPurpleAccent
                    )
                ) {
                    Text("Export Notes", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun AccountPanel(viewModel: PlanetViewModel) {
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val isDark = isSystemInDarkTheme()
    var activeAuthTab by remember { mutableStateOf("signin") }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant else BentoLilac
        ),
        border = BorderStroke(1.dp, if (isDark) Color.Transparent else BentoBorder)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            if (currentUser != null) {
                Text(
                    text = "Active Profile Info", 
                    fontSize = 16.sp, 
                    fontWeight = FontWeight.ExtraBold,
                    color = if (isDark) Color.White else BentoTextDark
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(if (isDark) MaterialTheme.colorScheme.primaryContainer else BentoLavender)
                            .border(1.5.dp, Color.White, CircleShape)
                    ) {
                        Text(
                            text = currentUser!!.name.take(2).uppercase(),
                            color = if (isDark) Color.White else BentoTextDark,
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = currentUser!!.name, 
                            fontWeight = FontWeight.ExtraBold, 
                            fontSize = 15.sp,
                            color = if (isDark) Color.White else BentoTextDark
                        )
                        Text(
                            text = currentUser!!.email, 
                            fontSize = 12.sp, 
                            color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText
                        )
                    }
                    Button(
                        onClick = { viewModel.signOut() },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.height(32.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
                    ) {
                        Text("Sign Out", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                Text(
                    text = "Keep your launchers personal", 
                    fontSize = 16.sp, 
                    fontWeight = FontWeight.ExtraBold,
                    color = if (isDark) Color.White else BentoTextDark
                )
                Text(
                    text = "Register or sign in so each workspace, launch counts, and notebooks remain private directly on this device.", 
                    fontSize = 12.sp, 
                    lineHeight = 16.sp,
                    color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText
                )
                
                Spacer(modifier = Modifier.height(14.dp))
                
                TabRow(
                    selectedTabIndex = if (activeAuthTab == "signin") 0 else 1,
                    containerColor = (if (isDark) Color.Black else Color.White).copy(alpha = 0.3f),
                    modifier = Modifier.clip(RoundedCornerShape(12.dp)),
                    indicator = { }
                ) {
                    Tab(
                        selected = activeAuthTab == "signin",
                        onClick = { activeAuthTab = "signin" },
                        text = { Text("Sign In", fontSize = 13.sp, fontWeight = FontWeight.Bold) },
                        selectedContentColor = if (isDark) Color.White else BentoTextDark,
                        unselectedContentColor = (if (isDark) Color.White else BentoTextDark).copy(alpha = 0.5f),
                        modifier = Modifier.background(
                            if (activeAuthTab == "signin") (if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color.White) else Color.Transparent
                        )
                    )
                    Tab(
                        selected = activeAuthTab == "signup",
                        onClick = { activeAuthTab = "signup" },
                        text = { Text("Sign Up", fontSize = 13.sp, fontWeight = FontWeight.Bold) },
                        selectedContentColor = if (isDark) Color.White else BentoTextDark,
                        unselectedContentColor = (if (isDark) Color.White else BentoTextDark).copy(alpha = 0.5f),
                        modifier = Modifier.background(
                            if (activeAuthTab == "signup") (if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color.White) else Color.Transparent
                        )
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                var emailInput by remember { mutableStateOf("") }
                var passwordInput by remember { mutableStateOf("") }
                var nameInput by remember { mutableStateOf("") }

                if (activeAuthTab == "signin") {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = emailInput,
                            onValueChange = { emailInput = it },
                            label = { Text("Email address", fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            shape = RoundedCornerShape(16.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = (if (isDark) Color.Black else Color.White).copy(alpha = 0.4f),
                                unfocusedContainerColor = (if (isDark) Color.Black else Color.White).copy(alpha = 0.25f)
                            )
                        )
                        OutlinedTextField(
                            value = passwordInput,
                            onValueChange = { passwordInput = it },
                            label = { Text("Password", fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            shape = RoundedCornerShape(16.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = (if (isDark) Color.Black else Color.White).copy(alpha = 0.4f),
                                unfocusedContainerColor = (if (isDark) Color.Black else Color.White).copy(alpha = 0.25f)
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Button(
                            onClick = { 
                                viewModel.signIn(emailInput, passwordInput) 
                                emailInput = ""
                                passwordInput = ""
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp),
                            shape = RoundedCornerShape(22.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isDark) MaterialTheme.colorScheme.primary else BentoPurpleAccent
                            )
                        ) {
                            Text("Sign In", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = nameInput,
                            onValueChange = { nameInput = it },
                            label = { Text("Full Name", fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = (if (isDark) Color.Black else Color.White).copy(alpha = 0.4f),
                                unfocusedContainerColor = (if (isDark) Color.Black else Color.White).copy(alpha = 0.25f)
                            )
                        )
                        OutlinedTextField(
                            value = emailInput,
                            onValueChange = { emailInput = it },
                            label = { Text("Email address", fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            shape = RoundedCornerShape(16.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = (if (isDark) Color.Black else Color.White).copy(alpha = 0.4f),
                                unfocusedContainerColor = (if (isDark) Color.Black else Color.White).copy(alpha = 0.25f)
                            )
                        )
                        OutlinedTextField(
                            value = passwordInput,
                            onValueChange = { passwordInput = it },
                            label = { Text("Password (min 6 chars)", fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            shape = RoundedCornerShape(16.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = (if (isDark) Color.Black else Color.White).copy(alpha = 0.4f),
                                unfocusedContainerColor = (if (isDark) Color.Black else Color.White).copy(alpha = 0.25f)
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Button(
                            onClick = { 
                                viewModel.signUp(nameInput, emailInput, passwordInput)
                                nameInput = ""
                                emailInput = ""
                                passwordInput = ""
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp),
                            shape = RoundedCornerShape(22.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isDark) MaterialTheme.colorScheme.primary else BentoPurpleAccent
                            )
                        ) {
                            Text("Create Account", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------
// MARKETPLACE SCREEN
// ---------------------------------------------
@Composable
fun MarketplaceScreen(viewModel: PlanetViewModel) {
    val query by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val selectedSort by viewModel.selectedSort.collectAsStateWithLifecycle()
    val filteredTools by viewModel.filteredMarketplaceTools.collectAsStateWithLifecycle()
    val activeContext by viewModel.activeContext.collectAsStateWithLifecycle()
    val isDark = isSystemInDarkTheme()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "AI Applications Marketplace",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 20.sp,
                color = if (isDark) Color.White else BentoTextDark,
                letterSpacing = (-0.5).sp
            )
            Text(
                text = "Choose from 500+ curated, widely used real tools. Search any category.",
                fontSize = 12.sp,
                color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = query,
                onValueChange = { viewModel.updateQuery(it) },
                placeholder = { Text("Search Claude.ai, Perplexity.ai, Cursor.so, design tools...", fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(20.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = if (isDark) MaterialTheme.colorScheme.primary else BentoPurpleAccent,
                    unfocusedBorderColor = if (isDark) Color.White.copy(alpha = 0.12f) else BentoBorder,
                    focusedContainerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color.White,
                    unfocusedContainerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f) else Color.White
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val sortOptions = listOf(
                    Pair("popular", "🔥 Popular"),
                    Pair("az", "🔤 A-Z"),
                    Pair("runtime", "⚙️ Runtime")
                )
                items(sortOptions) { (key, label) ->
                    FilterChip(
                        selected = selectedSort == key,
                        onClick = { viewModel.updateSort(key) },
                        label = { Text(label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        shape = RoundedCornerShape(14.dp)
                    )
                }

                item {
                    Spacer(modifier = Modifier.width(4.dp))
                    Box(
                        modifier = Modifier
                            .height(24.dp)
                            .width(1.dp)
                            .background(if (isDark) Color.White.copy(alpha = 0.15f) else BentoBorder)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                }

                val categories = listOf("all") + Catalog.categoryProfiles.keys.toList()
                items(categories) { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { viewModel.updateCategory(cat) },
                        label = { Text(cat.replace("&", "&&"), fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        shape = RoundedCornerShape(14.dp)
                    )
                }
            }
        }

        val installedTools by viewModel.installedTools.collectAsStateWithLifecycle()
        val recommendedTools = remember(activeContext, installedTools) {
            val installedIds = installedTools.map { it.id }.toSet()
            val categoryFilters = when (activeContext) {
                "work" -> listOf("Productivity", "Research & Data", "Marketing & Sales", "Coding Agents")
                "creative" -> listOf("Image & Design", "Video & Audio", "Chatbots & LLMs")
                "study" -> listOf("Research & Data", "Chatbots & LLMs", "Productivity")
                else -> listOf("Chatbots & LLMs", "Coding Agents", "Image & Design")
            }
            Catalog.list.filter { tool ->
                categoryFilters.contains(tool.category) && 
                !installedIds.contains(tool.id) &&
                !tool.id.endsWith("-pro")
            }.take(3)
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (query.isBlank() && selectedCategory == "all" && recommendedTools.isNotEmpty()) {
            Text(
                text = "✨ Dynamic Context Suggestions",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = if (isDark) Color.White else BentoTextDark,
                modifier = Modifier.padding(top = 4.dp, bottom = 6.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                recommendedTools.forEach { recTool ->
                    val recColor = remember(recTool.accent) {
                        try { Color(android.graphics.Color.parseColor(recTool.accent)) } catch (e: Exception) { SpaceYellowAccent }
                    }

                    Card(
                        modifier = Modifier
                            .width(220.dp)
                            .height(100.dp)
                            .clickable { viewModel.showToolDetails(recTool) },
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant else BentoBlue.copy(alpha = 0.3f)
                        ),
                        border = BorderStroke(1.dp, if (isDark) Color.Transparent else BentoBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(recColor.copy(alpha = 0.2f))
                            ) {
                                Text(
                                    text = recTool.name.take(2).uppercase(),
                                    color = recColor,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = recTool.name,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 12.sp,
                                    color = if (isDark) Color.White else BentoTextDark,
                                    maxLines = 1
                                )
                                Text(
                                    text = recTool.summary,
                                    fontSize = 10.sp,
                                    color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText,
                                    maxLines = 2,
                                    lineHeight = 12.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "+ Add to launcher",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDark) MaterialTheme.colorScheme.primary else BentoPurpleAccent
                                )
                            }
                        }
                    }
                }
            }
        }

        if (filteredTools.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No tools match search parameters.",
                    color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 145.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(filteredTools) { tool ->
                    MarketplaceCard(tool = tool, viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun MarketplaceCard(tool: Tool, viewModel: PlanetViewModel) {
    val installedTools by viewModel.installedTools.collectAsStateWithLifecycle()
    val isInstalled = remember(installedTools, tool.id) {
        installedTools.any { it.id == tool.id }
    }
    val isDark = isSystemInDarkTheme()

    var color = remember(tool.accent) {
        try { Color(android.graphics.Color.parseColor(tool.accent)) } catch (e: Exception) { SpaceYellowAccent }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(170.dp)
            .clickable { viewModel.showToolDetails(tool) },
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color.White
        ),
        border = BorderStroke(1.dp, if (isDark) Color.Transparent else BentoBorder)
    ) {
        Column(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(30.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(color.copy(alpha = 0.2f))
                    ) {
                        Text(
                            text = tool.name.take(2).uppercase(),
                            color = color,
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = tool.name,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp,
                        color = if (isDark) Color.White else BentoTextDark,
                        maxLines = 1,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = tool.summary,
                    fontSize = 11.sp,
                    color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText,
                    maxLines = 3,
                    lineHeight = 14.sp
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = tool.runtime.uppercase(Locale.getDefault()),
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Black,
                    color = if (isDark) Color.White else BentoTextDark,
                    modifier = Modifier
                        .background(
                            (if (isDark) MaterialTheme.colorScheme.primaryContainer else BentoLavender).copy(alpha = 0.5f),
                            shape = RoundedCornerShape(5.dp)
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )

                Button(
                    onClick = {
                        if (isInstalled) {
                            viewModel.showToolDetails(tool)
                        } else {
                            viewModel.installTool(tool)
                        }
                    },
                    modifier = Modifier.height(28.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isInstalled) {
                            if (isDark) MaterialTheme.colorScheme.surface else BentoBlue.copy(alpha = 0.4f)
                        } else {
                            if (isDark) MaterialTheme.colorScheme.primary else BentoPurpleAccent
                        },
                        contentColor = if (isInstalled) {
                            if (isDark) Color.White else BentoTextDark
                        } else {
                            Color.White
                        }
                    )
                ) {
                    Text(
                        text = if (isInstalled) "Added" else "Get",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// ---------------------------------------------
// WORKSPACE SCREEN
// ---------------------------------------------
@Composable
fun WorkspaceScreen(viewModel: PlanetViewModel) {
    val installedTools by viewModel.installedTools.collectAsStateWithLifecycle()
    val leftPaneToolId by viewModel.leftPaneToolId.collectAsStateWithLifecycle()
    val rightPaneToolId by viewModel.rightPaneToolId.collectAsStateWithLifecycle()
    val isWorkspaceLaunched by viewModel.isWorkspaceLaunched.collectAsStateWithLifecycle()

    val leftTool = remember(installedTools, leftPaneToolId) {
        installedTools.find { it.id == leftPaneToolId }
    }
    val rightTool = remember(installedTools, rightPaneToolId) {
        installedTools.find { it.id == rightPaneToolId }
    }

    var showLeftLaunchAlert by remember(leftTool) { mutableStateOf(false) }
    var showRightLaunchAlert by remember(rightTool) { mutableStateOf(false) }

    // Check on startup if those block embedded screens (ChatGPT, Claude block iframe-like embeds)
    val blockedEmbedIds = setOf(
        "chatgpt", "claude", "claude-ai", "gemini", "grok", "grok-com",
        "perplexity", "perplexity-ai", "microsoft-copilot", "meta-ai", "poe",
        "character-ai", "deepseek", "mistral-le-chat", "huggingchat", "pi", "you-com",
        "notebooklm-google-com", "notebook-llm"
    )
    val isLeftBlocked = remember(leftTool) {
        leftTool != null && (
            blockedEmbedIds.contains(leftTool.id) || 
            (leftTool.id.endsWith("-pro") && blockedEmbedIds.contains(leftTool.id.removeSuffix("-pro")))
        )
    }
    val isRightBlocked = remember(rightTool) {
        rightTool != null && (
            blockedEmbedIds.contains(rightTool.id) || 
            (rightTool.id.endsWith("-pro") && blockedEmbedIds.contains(rightTool.id.removeSuffix("-pro")))
        )
    }
    val isDark = isSystemInDarkTheme()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        if (!isWorkspaceLaunched) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(8.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .background(
                            if (isDark) MaterialTheme.colorScheme.surfaceVariant else BentoBlue.copy(alpha = 0.4f),
                            shape = CircleShape
                        )
                        .padding(16.dp)
                ) {
                    Icon(
                        Icons.Filled.Dashboard,
                        contentDescription = null,
                        modifier = Modifier.size(42.dp),
                        tint = if (isDark) Color.White else BentoTextDark
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Unified Side-by-Side Workspace",
                    fontWeight = FontWeight.Black,
                    fontSize = 20.sp,
                    color = if (isDark) Color.White else BentoTextDark,
                    textAlign = TextAlign.Center,
                    letterSpacing = (-0.5).sp
                )
                Text(
                    text = "Load two conversational models, research, or design tools next to each other in one screen helper.",
                    color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
                )

                Spacer(modifier = Modifier.height(28.dp))

                // Left Panel choice (Bento slot card)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant else BentoBlue
                    ),
                    border = BorderStroke(1.dp, if (isDark) Color.Transparent else BentoBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Left Window Panel", 
                            fontWeight = FontWeight.ExtraBold, 
                            fontSize = 12.sp,
                            color = if (isDark) Color.White else BentoTextDark
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        WorkspaceToolDropdown(
                            selectedToolId = leftPaneToolId,
                            toolsList = installedTools,
                            onSelect = { viewModel.setLeftPaneTool(it) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Right Panel choice (Bento slot card)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant else BentoPink
                    ),
                    border = BorderStroke(1.dp, if (isDark) Color.Transparent else BentoBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Right Window Panel", 
                            fontWeight = FontWeight.ExtraBold, 
                            fontSize = 12.sp,
                            color = if (isDark) Color.White else BentoTextDark
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        WorkspaceToolDropdown(
                            selectedToolId = rightPaneToolId,
                            toolsList = installedTools,
                            onSelect = { viewModel.setRightPaneTool(it) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "🧙‍♂️ Workflow Orchestrator Presets", 
                    fontWeight = FontWeight.ExtraBold, 
                    fontSize = 14.sp,
                    color = if (isDark) Color.White else BentoTextDark,
                    modifier = Modifier.align(Alignment.Start)
                )
                Text(
                    text = "Instantly configure and orchestrate optimized dual-AI workflows.",
                    fontSize = 11.sp,
                    color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText,
                    modifier = Modifier.align(Alignment.Start)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val context = LocalContext.current
                    val pastelBgs = listOf(BentoBlue, BentoPink, BentoLilac, BentoLavender)

                    val presetItems = listOf(
                        Triple("Creative Studio", "ChatGPT + Midjourney", Pair("chatgpt", "midjourney-com")),
                        Triple("Developer Suite", "Gemini + Cursor.so", Pair("gemini", "cursor-so")),
                        Triple("Deep Research", "Perplexity.ai + NotebookLM", Pair("perplexity-ai", "notebooklm-google-com")),
                        Triple("Growth Hack", "Claude.ai + Canva.com", Pair("claude-ai", "canva-com"))
                    )

                    presetItems.forEachIndexed { index, (pName, pDesc, ids) ->
                        val (leftId, rightId) = ids
                        Card(
                            modifier = Modifier
                                .width(180.dp)
                                .height(95.dp)
                                .clickable {
                                    val leftFound = Catalog.list.find { it.id == leftId }
                                    val rightFound = Catalog.list.find { it.id == rightId }
                                    if (leftFound != null) {
                                        viewModel.installTool(leftFound)
                                        viewModel.setLeftPaneTool(leftFound.id)
                                    }
                                    if (rightFound != null) {
                                        viewModel.installTool(rightFound)
                                        viewModel.setRightPaneTool(rightFound.id)
                                    }
                                    viewModel.launchWorkspace()
                                    Toast.makeText(context, "Launched $pName Preset!", Toast.LENGTH_SHORT).show()
                                },
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant else pastelBgs[index % pastelBgs.size].copy(alpha = 0.95f)
                            ),
                            border = BorderStroke(1.dp, if (isDark) Color.Transparent else BentoBorder)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = pName,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 12.sp,
                                        color = if (isDark) Color.White else BentoTextDark
                                    )
                                    Text(
                                        text = pDesc,
                                        fontSize = 10.sp,
                                        color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText,
                                        maxLines = 1
                                    )
                                }
                                Text(
                                    text = "Launch Workflow ⚡",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (isDark) MaterialTheme.colorScheme.primary else BentoPurpleAccent
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = { viewModel.launchWorkspace() },
                    enabled = leftPaneToolId != null || rightPaneToolId != null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isDark) MaterialTheme.colorScheme.primary else BentoPurpleAccent,
                        disabledContainerColor = (if (isDark) Color.White else BentoTextDark).copy(alpha = 0.12f)
                    )
                ) {
                    Text("Launch Active Workspace", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        } else {
            // Workspace Active View Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Running: ${(leftTool?.name ?: "—")} | ${(rightTool?.name ?: "—")}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = if (isDark) Color.White else BentoTextDark,
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )

                Button(
                    onClick = { viewModel.resetWorkspace() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.15f),
                        contentColor = MaterialTheme.colorScheme.error
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.height(30.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Text("Close Panel", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Split View layout with high corner WebViews
            val configuration = LocalConfiguration.current
            val isLandscape = configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
            
            if (isLandscape) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(20.dp))
                            .border(1.dp, if (isDark) Color.White.copy(alpha = 0.1f) else BentoBorder, RoundedCornerShape(20.dp))
                    ) {
                        WorkspacePaneContent(tool = leftTool, isBlocked = isLeftBlocked)
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(20.dp))
                            .border(1.dp, if (isDark) Color.White.copy(alpha = 0.1f) else BentoBorder, RoundedCornerShape(20.dp))
                    ) {
                        WorkspacePaneContent(tool = rightTool, isBlocked = isRightBlocked)
                    }
                }
            } else {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .border(1.dp, if (isDark) Color.White.copy(alpha = 0.1f) else BentoBorder, RoundedCornerShape(20.dp))
                    ) {
                        WorkspacePaneContent(tool = leftTool, isBlocked = isLeftBlocked)
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .border(1.dp, if (isDark) Color.White.copy(alpha = 0.1f) else BentoBorder, RoundedCornerShape(20.dp))
                    ) {
                        WorkspacePaneContent(tool = rightTool, isBlocked = isRightBlocked)
                    }
                }
            }
        }
    }
}

@Composable
fun WorkspaceToolDropdown(
    selectedToolId: String?,
    toolsList: List<Tool>,
    onSelect: (String?) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val isDark = isSystemInDarkTheme()
    val currentSelectedName = remember(selectedToolId, toolsList) {
        toolsList.find { it.id == selectedToolId }?.name ?: "— Choose installed tool —"
    }

    Box(modifier = Modifier.fillMaxWidth()) {
        OutlinedButton(
            onClick = { expanded = true },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.outlinedButtonColors(
                containerColor = (if (isDark) Color.Black else Color.White).copy(alpha = 0.3f),
                contentColor = if (isDark) Color.White else BentoTextDark
            ),
            border = BorderStroke(1.dp, if (isDark) Color.White.copy(alpha = 0.1f) else BentoBorder.copy(alpha = 0.5f))
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(currentSelectedName, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
            }
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.fillMaxWidth(0.9f)
        ) {
            DropdownMenuItem(
                text = { Text("— None —") },
                onClick = {
                    onSelect(null)
                    expanded = false
                }
            )
            toolsList.forEach { tool ->
                DropdownMenuItem(
                    text = { Text(tool.name) },
                    onClick = {
                        onSelect(tool.id)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
fun WorkspacePaneContent(tool: Tool?, isBlocked: Boolean) {
    val context = LocalContext.current
    val isDark = isSystemInDarkTheme()
    var webViewCrash by remember { mutableStateOf(false) }

    if (tool == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(if (isDark) MaterialTheme.colorScheme.surfaceVariant else BentoLavender.copy(alpha = 0.5f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "Empty Window Pane", 
                color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText, 
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
        }
        return
    }

    if (isBlocked || tool.runtime == "cli" || webViewCrash) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color.White),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    Icons.Filled.Lock, 
                    contentDescription = null, 
                    modifier = Modifier.size(32.dp), 
                    tint = MaterialTheme.colorScheme.error
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = tool.name, 
                    fontWeight = FontWeight.ExtraBold, 
                    fontSize = 14.sp,
                    color = if (isDark) Color.White else BentoTextDark
                )
                Text(
                    text = if (webViewCrash) {
                        "WebView system package is not available or has crashed on this device. You can open the tool link directly in an external browser instead."
                    } else if (tool.runtime == "cli") {
                        "CLI Tool - No web dashboard"
                    } else {
                        "Frame security block. This external site blocks embedding inside in-app window frames."
                    },
                    fontSize = 11.sp,
                    lineHeight = 15.sp,
                    textAlign = TextAlign.Center,
                    color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(tool.url))
                        context.startActivity(intent)
                    },
                    modifier = Modifier.height(32.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isDark) MaterialTheme.colorScheme.primary else BentoPurpleAccent
                    )
                ) {
                    Text("Open Externally ↗", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    } else {
        // Loads a actual functional webview for browsers supporting embedding
        key(tool.url) {
            AndroidView(
                factory = { context ->
                    try {
                        WebView(context).apply {
                            webViewClient = object : WebViewClient() {
                                override fun onRenderProcessGone(
                                    view: WebView?,
                                    detail: android.webkit.RenderProcessGoneDetail?
                                ): Boolean {
                                    // Recover gracefully if renderer process was terminated (e.g. out of memory)
                                    view?.loadUrl("about:blank")
                                    return true
                                }
                            }
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                databaseEnabled = true
                                useWideViewPort = true
                                loadWithOverviewMode = true
                                javaScriptCanOpenWindowsAutomatically = true
                            }
                            loadUrl(tool.url)
                        }
                    } catch (t: Throwable) {
                        t.printStackTrace()
                        webViewCrash = true
                        // Return dummy safe view so initialization inside factory succeeds without crashing UI thread
                        android.view.View(context)
                    }
                },
                update = { },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

// Extension to draw icon size in Icon
@Composable
fun Icon(imageVector: androidx.compose.ui.graphics.vector.ImageVector, contentDescription: String?, size: Dp, color: Color) {
    Icon(
        imageVector = imageVector,
        contentDescription = contentDescription,
        tint = color,
        modifier = Modifier.size(size)
    )
}

// ---------------------------------------------
// USAGE ANALYTICS SCREEN
// ---------------------------------------------
@Composable
fun AnalyticsScreen(viewModel: PlanetViewModel) {
    val analyticsLogs by viewModel.analyticsLogs.collectAsStateWithLifecycle()
    val scrollState = rememberScrollState()
    val isDark = isSystemInDarkTheme()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Usage Analytics",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 20.sp,
                    color = if (isDark) Color.White else BentoTextDark,
                    letterSpacing = (-0.5).sp
                )
                Text(
                    text = "Tracked 100% locally on this device.",
                    fontSize = 12.sp,
                    color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText
                )
            }

            Button(
                onClick = { viewModel.resetAnalytics() },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.15f),
                    contentColor = MaterialTheme.colorScheme.error
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.height(30.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
            ) {
                Text("Clear Logs", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Metrics Grid
        MetricsGrid(analyticsLogs)

        Spacer(modifier = Modifier.height(16.dp))

        // Category usage chart
        CategoryUsageCard(analyticsLogs)

        Spacer(modifier = Modifier.height(16.dp))

        // History Chart Card
        HistoryLogsCard(analyticsLogs)

        Spacer(modifier = Modifier.height(16.dp))

        // Top Tools Bar Chart Card
        TopToolsLeaderboardCard(analyticsLogs)
    }
}

@Composable
fun MetricsGrid(logs: List<AnalyticsLogEntity>) {
    val total = logs.size
    val minutesSaved = total * 4.5
    val isDark = isSystemInDarkTheme()
    
    // Streaks calculation based on consecutive active days
    val datesSet = logs.map { it.dateString }.toSet()
    var currentStreak = 0
    val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
    val cal = Calendar.getInstance()
    while (true) {
        val testStr = sdf.format(cal.time)
        if (datesSet.contains(testStr)) {
            currentStreak++
            cal.add(Calendar.DAY_OF_YEAR, -1)
        } else {
            break
        }
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        MetricCard(
            title = "Total Launches",
            value = total.toString(),
            icon = "🚀",
            bgColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant else BentoBlue,
            modifier = Modifier.weight(1f)
        )
        MetricCard(
            title = "Est saved time",
            value = if (minutesSaved >= 60) "${(minutesSaved / 60).toInt()}h" else "${minutesSaved.toInt()}m",
            icon = "⏱️",
            bgColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant else BentoPink,
            modifier = Modifier.weight(1f)
        )
        MetricCard(
            title = "Consec Streak",
            value = "${currentStreak}d",
            icon = "🔥",
            bgColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant else BentoLilac,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun MetricCard(title: String, value: String, icon: String, bgColor: Color, modifier: Modifier = Modifier) {
    val isDark = isSystemInDarkTheme()
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = bgColor),
        border = BorderStroke(1.dp, if (isDark) Color.Transparent else BentoBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title, 
                    fontSize = 10.sp, 
                    fontWeight = FontWeight.ExtraBold,
                    color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText,
                    maxLines = 1
                )
                Text(icon, fontSize = 13.sp)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = value, 
                fontSize = 24.sp, 
                fontWeight = FontWeight.Black, 
                color = if (isDark) Color.White else BentoTextDark
            )
        }
    }
}

@Composable
fun CategoryUsageCard(logs: List<AnalyticsLogEntity>) {
    val catCounts = logs.groupBy { it.category }.mapValues { it.value.size }
    val sortedCategoryCounts = Catalog.categoryProfiles.keys.map { category ->
        category to (catCounts[category] ?: 0)
    }.sortedByDescending { it.second }
    val isDark = isSystemInDarkTheme()

    val highestValue = sortedCategoryCounts.maxOfOrNull { it.second } ?: 1

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color.White
        ),
        border = BorderStroke(1.dp, if (isDark) Color.Transparent else BentoBorder)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text(
                text = "Usage by Category", 
                fontWeight = FontWeight.ExtraBold, 
                fontSize = 14.sp,
                color = if (isDark) Color.White else BentoTextDark
            )
            Spacer(modifier = Modifier.height(12.dp))
            
            if (logs.isEmpty()) {
                Text(
                    text = "No data yet. Launch tools from home screen to populate stats.", 
                    fontSize = 12.sp, 
                    color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    sortedCategoryCounts.forEach { (cat, count) ->
                        val pct = if (highestValue > 0) (count.toFloat() / highestValue) else 0f
                        val profile = Catalog.categoryProfiles[cat]
                        val rawColor = remember(profile?.accent) {
                            try { Color(android.graphics.Color.parseColor(profile?.accent ?: "#9FA8FF")) } catch (e: Exception) { CatResearch }
                        }
                        
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = cat, 
                                    fontSize = 11.sp, 
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDark) Color.White else BentoTextDark
                                )
                                Text(
                                    text = "$count launches", 
                                    fontSize = 11.sp, 
                                    color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(10.dp)
                                    .clip(CircleShape)
                                    .background((if (isDark) Color.Black else BentoBorder).copy(alpha = 0.3f))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(pct)
                                        .background(rawColor, CircleShape)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryLogsCard(logs: List<AnalyticsLogEntity>) {
    val logsByDate = logs.groupBy { it.dateString }.mapValues { it.value.size }
    val isDark = isSystemInDarkTheme()
    
    val dateList = remember {
        val list = mutableListOf<String>()
        val cal = Calendar.getInstance()
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        for (i in 0..6) {
            list.add(sdf.format(cal.time))
            cal.add(Calendar.DAY_OF_YEAR, -1)
        }
        list.reverse()
        list
    }

    val maxVal = remember(logsByDate) {
        logsByDate.values.maxOrNull()?.toFloat() ?: 1f
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color.White
        ),
        border = BorderStroke(1.dp, if (isDark) Color.Transparent else BentoBorder)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text(
                text = "Launch Activity (Last 7 Days)", 
                fontWeight = FontWeight.ExtraBold, 
                fontSize = 14.sp,
                color = if (isDark) Color.White else BentoTextDark
            )
            Spacer(modifier = Modifier.height(16.dp))
            
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(90.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                dateList.forEach { dateStr ->
                    val cnt = logsByDate[dateStr] ?: 0
                    val colHeightPct = if (maxVal > 0) (cnt.toFloat() / maxVal) else 0f
                    val displayLabel = dateStr.takeLast(5)
                    
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = cnt.toString(), 
                            fontSize = 10.sp, 
                            fontWeight = FontWeight.Black,
                            color = if (isDark) Color.White else BentoTextDark
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .width(20.dp)
                                .fillMaxHeight(colHeightPct.coerceAtLeast(0.08f))
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isDark) MaterialTheme.colorScheme.primary else BentoPurpleAccent)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = displayLabel, 
                            fontSize = 9.sp, 
                            fontWeight = FontWeight.Bold,
                            color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TopToolsLeaderboardCard(logs: List<AnalyticsLogEntity>) {
    val ranking = logs.groupBy { it.toolName }
        .mapValues { it.value.size }
        .toList()
        .sortedByDescending { it.second }
        .take(5)
    val isDark = isSystemInDarkTheme()

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color.White
        ),
        border = BorderStroke(1.dp, if (isDark) Color.Transparent else BentoBorder)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text(
                text = "Leaderboard: Most Launched", 
                fontWeight = FontWeight.ExtraBold, 
                fontSize = 14.sp,
                color = if (isDark) Color.White else BentoTextDark
            )
            Spacer(modifier = Modifier.height(12.dp))
            
            if (ranking.isEmpty()) {
                Text(
                    text = "Launch your installed tools to populate leaderboard logs.", 
                    fontSize = 12.sp, 
                    color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    ranking.forEachIndexed { idx, (name, count) ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "${idx + 1}",
                                fontWeight = FontWeight.Black,
                                color = if (isDark) MaterialTheme.colorScheme.primary else BentoPurpleAccent,
                                fontSize = 15.sp,
                                modifier = Modifier.width(24.dp)
                            )
                            Text(
                                text = name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = if (isDark) Color.White else BentoTextDark,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "$count launches",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText
                            )
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------
// MANAGE REPOSITORY SCREEN
// ---------------------------------------------
@Composable
fun ManageScreen(viewModel: PlanetViewModel) {
    val installedToolsByViewModel by viewModel.installedTools.collectAsStateWithLifecycle()
    val isDark = isSystemInDarkTheme()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Manage Work Desk",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 20.sp,
                    color = if (isDark) Color.White else BentoTextDark,
                    letterSpacing = (-0.5).sp
                )
                Text(
                    text = "Uninstall or check launch parameters for launcher cards.",
                    fontSize = 12.sp,
                    color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText
                )
            }

            Button(
                onClick = { viewModel.resetAllInstalls() },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.15f),
                    contentColor = MaterialTheme.colorScheme.error
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.height(30.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
            ) {
                Text("Uninstall All", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (installedToolsByViewModel.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Filled.Settings, 
                        contentDescription = null, 
                        modifier = Modifier.size(36.dp), 
                        tint = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoBorder
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "No local launchers installed yet.", 
                        color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText, 
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(installedToolsByViewModel) { tool ->
                    ManageToolItem(tool = tool, viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun ManageToolItem(tool: Tool, viewModel: PlanetViewModel) {
    var accentColor = remember(tool.accent) {
        try { Color(android.graphics.Color.parseColor(tool.accent)) } catch (e: Exception) { SpaceYellowAccent }
    }
    val isDark = isSystemInDarkTheme()

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color.White
        ),
        border = BorderStroke(1.dp, if (isDark) Color.Transparent else BentoBorder)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(accentColor.copy(alpha = 0.2f))
            ) {
                Text(
                    text = tool.name.take(2).uppercase(),
                    color = accentColor,
                    fontWeight = FontWeight.Black,
                    fontSize = 12.sp
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = tool.name, 
                    fontWeight = FontWeight.ExtraBold, 
                    fontSize = 14.sp,
                    color = if (isDark) Color.White else BentoTextDark
                )
                Text(
                    text = tool.category, 
                    fontSize = 11.sp, 
                    color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else BentoSubText,
                    fontWeight = FontWeight.Medium
                )
            }

            Button(
                onClick = { viewModel.removeTool(tool) },
                shape = RoundedCornerShape(14.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                modifier = Modifier.height(30.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.15f),
                    contentColor = MaterialTheme.colorScheme.error
                )
            ) {
                Text("Remove", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// ---------------------------------------------
// TOOL DETAILS MODAL DIALOG
// ---------------------------------------------
@Composable
fun ToolDetailsDialog(tool: Tool, viewModel: PlanetViewModel, onDismiss: () -> Unit) {
    val installedTools by viewModel.installedTools.collectAsStateWithLifecycle()
    val isInstalled = remember(installedTools, tool.id) {
        installedTools.any { it.id == tool.id }
    }
    
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current
    val isDark = isSystemInDarkTheme()
    val brushAccent = remember(tool.accent) {
        try { Color(android.graphics.Color.parseColor(tool.accent)) } catch (e: Exception) { SpaceYellowAccent }
    }

    val isAppInstalled = remember(tool) {
        val pkg = tool.getAndroidPackageName()
        if (pkg != null) {
            try {
                context.packageManager.getLaunchIntentForPackage(pkg) != null
            } catch (e: Exception) {
                false
            }
        } else {
            false
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 24.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(brushAccent.copy(alpha = 0.15f))
                        ) {
                            Text(
                                text = tool.name.take(2).uppercase(),
                                fontWeight = FontWeight.Bold,
                                color = brushAccent,
                                fontSize = 15.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(tool.name, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                            Text(tool.category, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Filled.Close, contentDescription = "Close dialog")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Aesthetic Description",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = tool.summary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Runtime parameters box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .padding(12.dp)
                ) {
                    Column {
                        Text(
                            text = if (tool.runtime == "cli") "CLI Setup parameters" else "Browser launcher parameters",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        
                        if (tool.runtime == "cli") {
                            Text(
                                text = "Install command:",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = brushAccent
                            )
                            SelectionContainer {
                                Text(
                                    text = "npm install -g @${tool.id}-cli",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Launch target cli parameter:",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = brushAccent
                            )
                            SelectionContainer {
                                Text(
                                    text = tool.note.ifBlank { tool.id },
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(vertical = 2.dp)
                                )
                            }
                        } else {
                            SelectionContainer {
                                Text(
                                    text = tool.url,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(vertical = 2.dp),
                                    maxLines = 2
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (tool.runtime != "cli") {
                        Button(
                            onClick = {
                                viewModel.recordToolLaunch(tool)
                                onDismiss()
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(tool.url))
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Cannot launch browser: ${tool.url}", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Web Sandbox ↗", fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                onDismiss()
                                launchOrDownloadTool(context, tool, viewModel)
                            },
                            modifier = Modifier.weight(1.2f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isDark) MaterialTheme.colorScheme.primary else BentoPurpleAccent
                            )
                        ) {
                            Text(if (isAppInstalled) "Launch App" else "Download App", fontSize = 12.sp)
                        }
                    } else {
                        Button(
                            onClick = {
                                val textToCopy = "npm install -g @${tool.id}-cli && ${tool.note.ifBlank { tool.id }}"
                                clipboardManager.setText(AnnotatedString(textToCopy))
                                Toast.makeText(context, "Copied installation script to clipboard", Toast.LENGTH_SHORT).show()
                                onDismiss()
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Copy CLI script")
                        }

                        Button(
                            onClick = {
                                onDismiss()
                                launchOrDownloadTool(context, tool, viewModel)
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isDark) MaterialTheme.colorScheme.primary else BentoPurpleAccent
                            )
                        ) {
                            Text("Install/Doc page", fontSize = 12.sp)
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            if (isInstalled) {
                                viewModel.removeTool(tool)
                            } else {
                                viewModel.installTool(tool)
                            }
                            onDismiss()
                        },
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = if (isInstalled) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Text(if (isInstalled) "Uninstall" else "Install card", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun isSystemInDarkTheme(): Boolean = com.example.ui.theme.LocalThemeIsDark.current


