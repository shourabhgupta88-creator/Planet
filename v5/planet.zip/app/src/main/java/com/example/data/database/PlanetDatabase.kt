package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        UserEntity::class,
        InstalledToolEntity::class,
        UserNoteEntity::class,
        AnalyticsLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class PlanetDatabase : RoomDatabase() {
    abstract fun planetDao(): PlanetDao

    companion object {
        @Volatile
        private var INSTANCE: PlanetDatabase? = null

        fun getDatabase(context: Context): PlanetDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PlanetDatabase::class.java,
                    "planet_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
