package com.example.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PlanetDao {

    // Users
    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    // Installed Tools
    @Query("SELECT * FROM installed_tools WHERE userId = :userId ORDER BY installedAt ASC")
    fun getInstalledToolsForUser(userId: String): Flow<List<InstalledToolEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInstalledTool(installedTool: InstalledToolEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInstalledTools(tools: List<InstalledToolEntity>)

    @Query("DELETE FROM installed_tools WHERE userId = :userId AND toolId = :toolId")
    suspend fun deleteInstalledTool(userId: String, toolId: String)

    @Query("DELETE FROM installed_tools WHERE userId = :userId")
    suspend fun clearInstalledTools(userId: String)

    // User Notes
    @Query("SELECT * FROM user_notes WHERE userId = :userId LIMIT 1")
    fun getNotesForUser(userId: String): Flow<UserNoteEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateNotes(notes: UserNoteEntity)

    // Analytics logs
    @Query("SELECT * FROM analytics_logs WHERE userId = :userId ORDER BY timestamp DESC")
    fun getAnalyticsLogsForUser(userId: String): Flow<List<AnalyticsLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnalyticsLog(log: AnalyticsLogEntity)

    @Query("DELETE FROM analytics_logs WHERE userId = :userId")
    suspend fun clearAnalyticsLogs(userId: String)
}
