package com.example.data

data class Tool(
    val id: String,
    val name: String,
    val url: String,
    val category: String,
    val summary: String,
    val accent: String, // Hex color code
    val rank: Int,
    val runtime: String, // "web" | "cli" | "hybrid"
    val note: String = "",
    val tags: List<String> = emptyList()
) {
    fun getAndroidPackageName(): String? {
        val baseId = id.removeSuffix("-pro")
        return when (baseId) {
            "chatgpt" -> "com.openai.chatgpt"
            "claude-ai", "claude" -> "com.anthropic.claude"
            "gemini" -> "com.google.android.apps.bard"
            "microsoft-copilot", "copilot" -> "com.microsoft.copilot"
            "perplexity-ai", "perplexity" -> "com.perplexity.app"
            "canva-com", "canva" -> "com.canva.editor"
            "notion-so", "notion" -> "notion.id"
            "grammarly" -> "com.grammarly.android.keyboard"
            "poe" -> "com.poe.android"
            "character-ai" -> "ai.character.app"
            "replika" -> "com.replika.ai"
            "deepseek" -> "com.deepseek.chat"
            "kimi" -> "com.moonshot.kimi"
            "speechify-com", "speechify" -> "com.speechify"
            "otter-ai", "otter" -> "com.otter.media"
            "taskade-com", "taskade" -> "com.taskade.mobile"
            "clickup-com", "clickup" -> "com.clickup.gandalf"
            "asana-ai", "asana" -> "com.asana.app"
            "monday-ai", "monday" -> "com.monday.monday"
            "slack-ai", "slack" -> "com.Slack"
            "zoom-ai-companion", "zoom" -> "us.zoom.videomeetings"
            "hubspot-breeze", "hubspot" -> "com.hubspot.android"
            "salesforce-einstein", "salesforce" -> "com.salesforce.chatter"
            "zendesk-ai", "zendesk" -> "com.zendesk.android"
            else -> null
        }
    }

    fun getDownloadUrl(): String {
        val baseId = id.removeSuffix("-pro")
        
        val mappedUrl = when (baseId) {
            "vs-code", "visual-studio-code" -> "https://code.visualstudio.com/Download"
            "project-idx" -> "https://idx.google.com"
            "supermaven" -> "https://supermaven.com"
            "pycharm-ai" -> "https://www.jetbrains.com/pycharm/download/"
            "webstorm-ai" -> "https://www.jetbrains.com/webstorm/download/"
            "cursor-so", "cursor" -> "https://cursor.com/download"
            "windsurf" -> "https://codeium.com/windsurf"
            "google-antigravity" -> "https://antigravity.google"
            "replit-com", "replit" -> "https://replit.com/desktop"
            "figma-ai", "figma" -> "https://www.figma.com/ai"
            "obsidian" -> "https://obsidian.md/download"
            "claude-code" -> "https://www.anthropic.com/claude-code"
            "aider" -> "https://aider.chat"
            "cline" -> "https://marketplace.visualstudio.com/items?itemName=saoudrizwan.claude-dev"
            "roo-code" -> "https://marketplace.visualstudio.com/items?itemName=RooVeterinaryInc.roo-cline"
            "continue" -> "https://marketplace.visualstudio.com/items?itemName=Continue.continue"
            "github-copilot" -> "https://marketplace.visualstudio.com/items?itemName=GitHub.copilot"
            "amazon-q-developer" -> "https://marketplace.visualstudio.com/items?itemName=AmazonWebServices.amazon-q-vscode"
            "gemini-code-assist" -> "https://marketplace.visualstudio.com/items?itemName=Google.gemini-code-assist"
            "sourcegraph-cody", "cody" -> "https://marketplace.visualstudio.com/items?itemName=sourcegraph.cody-ai"
            "zed-ai", "zed" -> "https://zed.dev"
            "tabnine-com", "tabnine" -> "https://www.tabnine.com/install"
            else -> null
        }
        
        if (mappedUrl != null) {
            return mappedUrl
        }
        
        if (category == "Coding Agents") {
            return url
        }
        
        val pkg = getAndroidPackageName()
        if (pkg != null) {
            return "https://play.google.com/store/apps/details?id=$pkg"
        }
        
        val encoded = name.replace(" ", "%20").replace("&", "%26")
        return "https://play.google.com/store/search?q=$encoded&c=apps"
    }
}
