package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color

val LocalThemeIsDark = compositionLocalOf { false }

private val DarkColorScheme = darkColorScheme(
    primary = BentoLavender,
    secondary = BentoBlue,
    tertiary = BentoPink,
    background = DarkBackground,
    surface = DarkSurface,
    surfaceVariant = DarkSurfaceVariant,
    primaryContainer = BentoPurpleAccent,
    secondaryContainer = DarkSurfaceVariant,
    tertiaryContainer = Color(0xFF3D2E3C),
    onPrimary = Color.Black,
    onSecondary = Color.Black,
    onBackground = Color(0xFFF3EDF7),
    onSurface = Color(0xFFF3EDF7),
    onSurfaceVariant = Color(0xFFC4C1C6)
)

private val LightColorScheme = lightColorScheme(
    primary = BentoPurpleAccent,
    secondary = BentoBlue,
    tertiary = BentoPink,
    background = LightBackground,
    surface = LightSurface,
    surfaceVariant = LightSurfaceVariant,
    primaryContainer = BentoLavender,
    secondaryContainer = BentoBlue,
    tertiaryContainer = BentoPink,
    onPrimary = Color.White,
    onSecondary = BentoTextDark,
    onBackground = BentoTextDark,
    onSurface = BentoTextDark,
    onSurfaceVariant = BentoSubText
)

@Composable
fun PlanetTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    CompositionLocalProvider(LocalThemeIsDark provides darkTheme) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
