package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Bento Grid design theme specific colors
val BentoBgWarm = Color(0xFFFDF8F6)
val BentoTextDark = Color(0xFF1D1B1E)
val BentoSubText = Color(0xFF49454F)

// Pastel accent colors
val BentoLilac = Color(0xFFF3EDF7)
val BentoLavender = Color(0xFFE8DEF8)
val BentoBlue = Color(0xFFD0E4FF)
val BentoPink = Color(0xFFFFD8E4)
val BentoPurpleAccent = Color(0xFF6750A4)
val BentoBorder = Color(0xFFE6E1E5)

// Brand colors
val SpaceGreyClassic = Color(0xFF1C1D21)
val SpaceGreyLight = Color(0xFF2C2D32)
val SpaceYellowAccent = Color(0xFFFFCC00)

val DarkBackground = Color(0xFF141517)
val DarkSurface = Color(0xFF1B1A1D)
val DarkSurfaceVariant = Color(0xFF2D2A2E)
val LightBackground = BentoBgWarm
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = BentoLilac

// Categories
val CatChatbot = Color(0xFF55B7FF)
val CatCoding = Color(0xFF36D399)
val CatImage = Color(0xFFFF8BD1)
val CatVideo = Color(0xFFFFBF5F)
val CatProductivity = Color(0xFFB9F26D)
val CatResearch = Color(0xFF9FA8FF)
val CatMarketing = Color(0xFFF79256)
